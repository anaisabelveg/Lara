function mostrarNumeros(){

    var num = numero.value;

    document.getElementById("resultadoNumero").innerHTML =
        "Logaritmo: " + Math.log(num) + "<br/>" +
        "Exponencial: " + Math.exp(num) + "<br/>" +
        "Raiz cuadrada: " + Math.sqrt(num) + "<br/>" +
        "Potencia elevado a 2: " + Math.pow(num,2) + "<br/>" +
        "Redondeo floor bajo: " + Math.floor(num) + "<br/>" +
        "Redondeo ceil alto: " + Math.ceil(num) + "<br/>" +
        "Redondeo round medio: " + Math.round(num) + "<br/>" +
        "Random: " + Math.random() + "<br/>" +
        "Random 0-100: " + Math.random() * 100 + "<br/>" +
        "Random 0-1000: " + Math.random() * 1000 + "<br/>" +
        "Coseno de 180 grados: " + Math.cos(Math.PI/2) + "<br/>" +
        "Valor maximo: " + Math.max(5,2,8,3) + "<br/>" +
        "Valor minimo: " + Math.min(5,2,8,3) + "<br/>";

}

function mostrarTextos(){
    var cadena = texto.value;
    document.getElementById("resultadoTexto").innerHTML =
        "Minusculas: " + cadena.toLowerCase() + "<br/>" +
        "Mayusculas: " + cadena.toUpperCase() + "<br/>" +
        "Primera a: " + cadena.indexOf('a') + "<br/>" +
        "Ultimo a: " + cadena.lastIndexOf('a') + "<br/>" +
        "Subcadena substr(posicion,longitud?): " + cadena.substr(5,6) + "<br/>" +
        "Subcadena substr(posicion): " + cadena.substr(5) + "<br/>" +
        "Subcadena slice(pos_inicio,pos_final?): " + cadena.slice(5,6) + "<br/>" +
        "Subcadena slice(pos_inicio): " + cadena.slice(5) + "<br/>" +
        "Subcadena substring(pos_inicio,pos_final): " + cadena.substring(5,6) + "<br/>" +
        "Caracter unicode: " + String.fromCharCode(960) + "<br/>" +
        "Unicode: " + cadena.charCodeAt(5) + "<br/>" +
        "Representa UTF-16 de un caracter " + cadena.codePointAt(5) + "<br/>";

        var array = cadena.split(" ");
        alert(array.length);
}

function mostrarFechas(){
    var fecha = new Date(miFecha.value);
    document.getElementById("resultadoFecha").innerHTML =
        "Fecha: " + fecha + "<br/>" +
        "getTime: " + fecha.getTime() + "<br/>" +
        "getTimezoneOffset: " + fecha.getTimezoneOffset() + "<br/>" +
        "getHours: " + fecha.getHours() + "<br/>" +
        "getMinutes: " + fecha.getMinutes() + "<br/>" +
        "getSeconds: " + fecha.getSeconds() + "<br/>" +
        "getMilliseconds: " + fecha.getMilliseconds() + "<br/>" +
        "getDate: " + fecha.getDate() + "<br/>" +
        "getYear: " + fecha.getYear() + "<br/>" +
        "getFullYear: " + fecha.getFullYear() + "<br/>" +
        "getMonth: " + fecha.getMonth() + "<br/>" +
        "getDay: " + fecha.getDay() + "<br/>";
}
function cargarProvincias(){
    var nombresProv = ["Madrid","Valladolid","Sevilla"];

    for (var i=0 in nombresProv) {
        var opt = new Option(nombresProv[i],i);
        document.getElementById("provinciasId")
            .options[parseInt(i)+1] = opt;
    }
}

function cargarPoblaciones(){
    var nombresPobl = new Array();

    // Borramos todos los options anteriores
    for(var i=0 in document.getElementById("poblacionesId")
    .options){
        document.getElementById("poblacionesId")
            .options[i] = null;
    }
    
    // Agregamos la opcion de seleccionar
    document.getElementById("poblacionesId")
            .options[0] = new Option("--Selecciona--");

    switch(provinciasId.value){
        case "0":
            nombresPobl = ["Getafe","Alcorcon","Pozuelo"];
            break;
        case "1":
            nombresPobl = ["Rueda","Medina del Campo","Serrada"];
            break;
        case "2":
            nombresPobl = ["Dos Hermanas","Espartinas"];
            break;
    }

    for (var i=0 in nombresPobl) {
        var opt = new Option(nombresPobl[i],i);
        document.getElementById("poblacionesId")
            .options[parseInt(i)+1] = opt;
    }
}
function validar(evt){
    if (/^[A-Z][a-z]{3,20}$/.test(formulario.idNombre.value)){
        document.getElementById("resultado").innerText = "";
    }else{
        document.getElementById("resultado").innerText = 
          "Nombre incorrecto debe tener entre 3 y 20 caracteres";
        // Cancelar el submit
        evt.preventDefault();
    }
}

function cargar(){
    var array = new Array("Tecnico","Profesional","Junior");

    for(var indice in array){
        var opcion = new Option(array[indice],indice);
        document.getElementById("categoria").options[indice] = opcion;
    }
}
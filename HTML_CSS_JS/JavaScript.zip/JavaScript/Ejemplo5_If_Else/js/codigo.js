var estiloBorde = false;
var estiloColor = false;
var estiloSombra = false;

function mostrarTipo(){
    if (document.getElementById("conducir_si").checked == true){
        document.getElementById("tipo").style.display = "block";
    } else {
        document.getElementById("tipo").style.display = "none";
    }
}

function sombra(){
    if (!estiloSombra){
        document.getElementById("contenido")
            .style.boxShadow = "5px 5px 3px #aaa";
        estiloSombra = true;    
    } else {
        document.getElementById("contenido")
            .style.boxShadow = "none";
        estiloSombra = false; 
    }
}

function color(){
    if (!estiloColor){
        document.getElementById("contenido")
            .style.backgroundColor = "green";
        estiloColor = true;    
    } else {
        document.getElementById("contenido")
            .style.backgroundColor = "coral";
        estiloColor = false; 
    }
}

function borde(){
    if (!estiloBorde){
        document.getElementById("contenido")
            .style.border = "5px solid blue";
        estiloBorde = true;    
    } else {
        document.getElementById("contenido")
            .style.border = "none";
        estiloBorde = false; 
    }
}
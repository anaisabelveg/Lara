package vegas.anabel.web;


import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class ListenerAplicacion implements ServletContextListener{

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContextListener.super.contextInitialized(sce);
		
		// Recuperar el contexto de la aplicacion
		ServletContext ctxApp = sce.getServletContext();
		
		// Recupero el parametro inicial
		String mensaje = ctxApp.getInitParameter("Blackfriday");
		
		// Lo guardo en el contexto de la aplicacion como atributo
		ctxApp.setAttribute("black", mensaje);
		
		System.out.println("---------- Se ha creado el contexto de la aplicacion ---------");
	}
	
	
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		ServletContextListener.super.contextDestroyed(sce);
		System.out.println("---------- Se ha destruido el contexto de la aplicacion ---------");
	}
}















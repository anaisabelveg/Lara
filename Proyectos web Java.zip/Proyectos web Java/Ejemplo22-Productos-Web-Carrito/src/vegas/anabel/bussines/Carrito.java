package vegas.anabel.bussines;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import vegas.anabel.models.Producto;
import vegas.anabel.persistence.ProductosDAO;

public class Carrito implements Serializable{
	
	private List<Producto> contenido = new ArrayList<Producto>();
	private double importe;
	
	public void eliminarProducto(int id) {
		Producto eliminar = null;
		for (Producto producto : contenido) {
			if (id == producto.getId()) {
				eliminar = producto;
				break;
			}
		}
		importe -= eliminar.getPrecio();
		contenido.remove(eliminar);
	}
	
	public void agregarProducto(int id) {
		ProductosDAO dao = new ProductosDAO();
		Producto producto = dao.buscarPorId(id);
		contenido.add(producto);
		importe += producto.getPrecio();
	}
	
	public List<Producto> getContenido() {
		return contenido;
	}
	
	public double getImporte() {
		return importe;
	}

}











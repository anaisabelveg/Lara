package vegas.anabel.bussines;

import java.util.List;

import vegas.anabel.models.Producto;
import vegas.anabel.persistence.ProductosDAO;

public class ProductosBS {
	
	public void modificar(int id, double nuevoPrecio) {
		ProductosDAO dao = new ProductosDAO();
		dao.modificar(id, nuevoPrecio);
	}
	
	public void eliminar(int id) {
		ProductosDAO dao = new ProductosDAO();
		dao.eliminar(id);
	}
	
	public void insertar(Producto nuevo) {
		ProductosDAO dao = new ProductosDAO();
		dao.alta(nuevo);
	}
	
	public List<Producto> buscar(String descripcion){
		ProductosDAO dao = new ProductosDAO();
		return dao.buscarPorDescripcion(descripcion);
	}
	
	public List<Producto> consultarTodos(){
		ProductosDAO dao = new ProductosDAO();
		return dao.todos();
	}
	
	public Producto buscar(int id) {
		ProductosDAO dao = new ProductosDAO();
		return dao.buscarPorId(id);
	}

}

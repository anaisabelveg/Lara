package com.example.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletChat
 */
@WebServlet("/ServletChat")
public class ServletChat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletChat() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String vista = "/index.jsp";
		
		// Recupero el parametro op
		switch (request.getParameter("op")) {
		case "1":
			HttpSession sesion = request.getSession();
			sesion.setAttribute("nombre", request.getParameter("nombre"));	
			vista = "/index.jsp";
			break;

		default:
			sesion = request.getSession();
			String nombre = (String) sesion.getAttribute("nombre");
			if (nombre == null) {
				vista = "/login.html";
			} else {
				// Recupero el mensaje recibido
				String msg = request.getParameter("mensaje");
				
				// Recuperar el contexto de aplicacion
				ServletContext sce = request.getServletContext();
				
				// Si existe el atributo lista_mensajes
				List<String> lista = (List<String>) sce.getAttribute("lista_mensajes");
				
				if (lista == null) {
					lista = new ArrayList<String>();
					sce.setAttribute("lista_mensajes", lista);
				} 
				
				// Guardar el mensaje como atributo del contexto
				lista.add(nombre + ": " + msg);
			}
			
			break;
		}
			
		// Redirigir a la pagina index
		RequestDispatcher rd = request.getRequestDispatcher(vista);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

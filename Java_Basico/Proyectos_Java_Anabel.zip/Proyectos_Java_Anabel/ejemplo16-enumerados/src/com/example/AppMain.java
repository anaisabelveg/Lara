package com.example;

import java.util.Arrays;

public class AppMain {

	public static void main(String[] args) {
		
		Persona p1 = new Persona("Juan", 27, EstadoCivil.CASADO);
		Persona p2 = new Persona("Maria", 56, EstadoCivil.DIVORCIADO);
		Persona p3 = new Persona("Jorge", 45, EstadoCivil.PAREJA_HECHO);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		System.out.println(Arrays.toString(EstadoCivil.values()));
		System.out.println(EstadoCivil.CASADO.ordinal());

	}

}

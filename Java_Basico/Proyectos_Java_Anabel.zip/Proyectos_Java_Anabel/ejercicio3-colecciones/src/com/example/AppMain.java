package com.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		// Cree un programa almacene números del 0 al 9 en un array y en una lista, e imprima
		//sus valores.

		int miArray[] = {0,1,2,3,4,5,6,7,8,9};
		System.out.println(Arrays.toString(miArray));
		
		List<Integer> numeros = new ArrayList<>();
		numeros.add(0);
		numeros.add(1);
		numeros.add(2);
		numeros.add(3);
		numeros.add(4);
		numeros.add(5);
		numeros.add(6);
		numeros.add(7);
		numeros.add(8);
		numeros.add(9);
		System.out.println(numeros);
		
		
		
	}

}

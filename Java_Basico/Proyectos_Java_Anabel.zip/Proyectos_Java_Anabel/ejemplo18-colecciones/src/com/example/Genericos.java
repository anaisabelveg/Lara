package com.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Genericos {

	public static void main(String[] args) {
		// Set -> No elementos repetidos
		//        No garantizamos orden de entrada 
		
		// List -> Si elementos repetidos
		//        Si garantizamos orden de entrada 
		
		Set<String> set = new HashSet<String>();
		set.add("Hola");
		set.add("7");
		set.add("true");
		set.add("c");
		set.add("Hola");
		System.out.println(set);		
		
		List<Integer> lista = new ArrayList<Integer>();
		lista.add(8);
		lista.add(7);
		lista.add(new Integer(9));
		lista.add(3);
		lista.add(2);
		System.out.println(lista);
			
		
		// Recorrer una coleccion a partir de Java 5
		for (String object : set) {
			System.out.println(object);
		}
		
		// Recorrer una lista con iterator
		Iterator<Integer> iterator = lista.listIterator();
		while(iterator.hasNext()) {
			int object = iterator.next();
			System.out.println(object);
		}

		Map<String, Integer> mapa = new HashMap<String, Integer>();
		mapa.put("Pepe", 20);
		mapa.put("Juan", 20);
		mapa.put("Pepito", 38);
		mapa.put("Manuela", 19);
		mapa.put("Jorge", 56);
		
		System.out.println(mapa);
		
		// Recorrer un mapa
		for (String object : mapa.keySet()) {
			System.out.println(object);
		}
	}

}









package com.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class AppMain {

	public static void main(String[] args) {
		// Set -> No elementos repetidos
		//        No garantizamos orden de entrada 
		
		// List -> Si elementos repetidos
		//        Si garantizamos orden de entrada 
		
		Set set = new HashSet();
		set.add("Hola");
		set.add(7);
		set.add(true);
		set.add('c');
		set.add("Hola");
		System.out.println(set);
		
		
		List lista = new ArrayList();
		lista.add("Hola");
		lista.add(7);
		lista.add(true);
		lista.add('c');
		lista.add("Hola");
		System.out.println(lista);
		
		// Recuperar elementos de una coleccion
		System.out.println(lista.get(0));
		
		// Ver si esta vacia
		System.out.println(set.isEmpty());
		
		// Tamaño de la coleccion
		System.out.println(set.size());
		
		// Ver si contiene un objeto
		System.out.println(lista.contains('c'));
		
		// Eliminar un objeto
		System.out.println(set.remove(7));
		System.out.println(set);
		System.out.println(lista.remove(0));
		System.out.println(lista);
		
		// Recorrer una coleccion a partir de Java 5
		for (Object object : set) {
			System.out.println(object);
		}
		
		// Recorrer una lista con iterator
		Iterator iterator = lista.listIterator();
		while(iterator.hasNext()) {
			Object object = iterator.next();
			System.out.println(object);
		}

		Map mapa = new HashMap();
		mapa.put("hola", 20);
		mapa.put(true, 20);
		mapa.put('c', "Pepito");
		mapa.put("hola", "Adios");
		mapa.put(new Integer(27), 6.45);
		
		System.out.println(mapa);
		System.out.println(mapa.values());
		System.out.println(mapa.keySet());
		System.out.println(mapa.entrySet());
		
		// Recuperar un dato
		System.out.println(mapa.get("hola"));
		
		// Borrar un elemento
		System.out.println(mapa.remove(true));
		
		// Preguntar si esta vacia
		System.out.println(mapa.isEmpty());
		
		// Preguntar si contiene la clave 'hola'
		System.out.println(mapa.containsKey("hola"));
		
		// Si contiene el valor 6.45
		System.out.println(mapa.containsValue(6.45));
		
		// Recorrer un mapa
		for (Object object : mapa.entrySet()) {
			System.out.println(object);
		}
	}

}









package vegas.anabel.cliente;

import java.util.Scanner;

import vegas.anabel.business.Agenda;
import vegas.anabel.models.Contacto;

public class AppMain {
	
	Agenda agenda = new Agenda();

	public static void main(String[] args) {

		AppMain objMain = new AppMain();
		String opcion = "";

		// Un bucle hasta que pulse S
		do {

			// Mostrar el menu al usuario
			System.out.println("Menu de opciones:");
			System.out.println("----------------");
			System.out.println("1.- Mostrar todos");
			System.out.println("2.- Buscar un contacto");
			System.out.println("3.- Agregar nuevo");
			System.out.println("4.- Eliminar contacto");
			System.out.println("5.- Cambiar telefono");
			System.out.println("6.- Cambiar email");
			System.out.println("Salir (S)");

			System.out.println("Introduce opcion (1-6, S salir)");
			Scanner sc = new Scanner(System.in);
			opcion = sc.next();

			// Segun la opcion elegida (switch-case)
			switch (opcion) {
			case "1":
				objMain.mostrarTodos();
				break;

			case "2":
				objMain.buscar();
				break;

			case "3":
				objMain.agregarNuevo();
				break;

			case "4":
				objMain.eliminar();
				break;

			case "5":
				objMain.cambiarTfno();
				break;

			case "6":
				objMain.cambiarEmail();
				break;

			case "S":
			case "s":
				break;

			default:
				break;
			}

		} while (!opcion.equalsIgnoreCase("S"));
	}

	private  void cambiarEmail() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nombre: ");
		String nombre = sc.nextLine();
		System.out.println("Introduce email: ");
		String nuevoEmail = sc.nextLine();
		agenda.cambiarEmail(nombre, nuevoEmail);
	}

	private  void cambiarTfno() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nombre: ");
		String nombre = sc.nextLine();
		System.out.println("Introduce telefono: ");
		String nuevoTfno = sc.nextLine();
		agenda.cambiarTfno(nombre, nuevoTfno);
	}

	private  void eliminar() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nombre: ");
		String nombre = sc.nextLine();
		agenda.eliminar(nombre);
	}

	private  void agregarNuevo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nombre: ");
		String nombre = sc.nextLine();
		System.out.println("Introduce telefono: ");
		String telefono = sc.nextLine();
		System.out.println("Introduce email: ");
		String email = sc.nextLine();
		Contacto nuevo = new Contacto(nombre, telefono, email);
		agenda.agregar(nuevo);
	}

	private  void buscar() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce nombre: ");
		String nombre = sc.nextLine();
		System.out.println(agenda.buscar(nombre));
	}

	private  void mostrarTodos() {	
		for (Contacto c: agenda.mostrarTodos()) {
			System.out.println(c);
		}
	}

}







package vegas.anabel.business;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import vegas.anabel.models.Contacto;

public class Agenda {
	
	private Set<Contacto> contactos = new HashSet<>();
	
	// inicialidadores
	{
		contactos.add(new Contacto("Pepe", "616111111", "pepe@gmail.com"));
		contactos.add(new Contacto("Maria", "616222222", "maria@gmail.com"));
	}
	
	public Set<Contacto> mostrarTodos(){
		Set<Contacto> contactosOrdenados = new TreeSet<>(new Comparator<Contacto>() {

			@Override
			public int compare(Contacto c1, Contacto c2) {
				return c1.getNombre().compareTo(c2.getNombre());
			}
			
		});
		
		contactosOrdenados.addAll(contactos);
		
		return contactosOrdenados;
	}

	public Contacto buscar(String nombre) {
		Contacto encontrado = null;
		for (Contacto contacto : contactos) {
			if (nombre.equals(contacto.getNombre())){
				encontrado = contacto;
			}
		}
		return encontrado;
	}
	
	public void agregar(Contacto contacto) {
		contactos.add(contacto);
	}
	
	public void eliminar(String nombre) {
		Contacto encontrado = null;
		
		// No puedo borrar un objeto dentro de un for-each
		for (Contacto contacto : contactos) {
			// Si lo encuentro, lo almaceno en una variable
			if (nombre.equals(contacto.getNombre())){
				encontrado = contacto;
			}
		}
		// Al terminar el bucle lo puedo borrar
		contactos.remove(encontrado);
	}
	
	public void cambiarTfno(String nombre, String nuevoTfno) {
		for (Contacto contacto : contactos) {
			if (nombre.equals(contacto.getNombre())){
				contacto.setTelefono(nuevoTfno);
			}
		}
	}
	
	public void cambiarEmail(String nombre, String nuevoEmail) {
		for (Contacto contacto : contactos) {
			if (nombre.equals(contacto.getNombre())){
				contacto.setEmail(nuevoEmail);
			}
		}
	}
	

}

package com.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppMain {

	public static void main(String[] args) {
		// Cree un programa que implemente un diccionario. El diccionario debe contener
		// palabras en castellano y una lista de posibles significados de cada palabra.
		// Crear la clase Palabra que permita almacenar la información de una palabra,
		// junto con
		// sus definiciones.
		// Utilizar un objeto HashMap para almacenar palabras en la clase Diccionari

		Map<String, List<String>> diccionario = new HashMap<>();
		
		for(int i=1; i<=5; i++) {
			Palabra palabra = new Palabra();
			palabra.setPalabra("Palabra " + i);
			palabra.getDefiniciones().add("Definicion 1");
			palabra.getDefiniciones().add("Definicion 2");
			palabra.getDefiniciones().add("Definicion 3");
			
			diccionario.put(palabra.getPalabra(), palabra.getDefiniciones());
		}
		
		System.out.println(diccionario);
	}

}





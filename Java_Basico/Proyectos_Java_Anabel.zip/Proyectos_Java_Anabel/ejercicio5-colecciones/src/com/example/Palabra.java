package com.example;

import java.util.ArrayList;
import java.util.List;

public class Palabra {

	private String palabra;
	private List<String> definiciones = new ArrayList<>();

	public String getPalabra() {
		return palabra;
	}

	public void setPalabra(String palabra) {
		this.palabra = palabra;
	}

	public List<String> getDefiniciones() {
		return definiciones;
	}

	public void setDefiniciones(List<String> definiciones) {
		this.definiciones = definiciones;
	}

	@Override
	public String toString() {
		return "Palabra [palabra=" + palabra + ", definiciones=" + definiciones + "]";
	}
	
	

}

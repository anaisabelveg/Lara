package com.example;

public class Ejercicio3 {

	public static void main(String[] args) {
		// Calcular la suma de los números pares comprendidos entre 10 y 50
		
		int resultado = 0;
		int numero = 10;
		
		do {
			if (numero % 2 == 0) {
				resultado += numero;
			}
			numero++;
			
		} while(numero <= 50);
		
		System.out.println("La suma es " + resultado);

	}

}

package com.example;

import java.util.Random;

public class AppMain {

	public static void main(String[] args) {
		
		System.out.println(Palo.values()[1]);
		System.out.println(new Random().nextInt(3));
		System.out.println((int)(Math.random() * 4));
		
		for(int i=1; i<=7; i++) {
			int numPalo = (int)(Math.random() * 4);
			int numValor = (int)(Math.random() * 10);
			System.out.println(new Carta(Palo.values()[numPalo], 
					Valor.values()[numValor]));
		}

	}

}

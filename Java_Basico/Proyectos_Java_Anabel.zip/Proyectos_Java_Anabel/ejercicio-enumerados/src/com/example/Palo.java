package com.example;

public enum Palo {

	OROS, COPAS, ESPADAS, BASTOS
}

package com.example;

public class Carta {
	
	private Palo palo;
	private Valor valor;
	
	public Carta() {
		// TODO Auto-generated constructor stub
	}

	public Carta(Palo palo, Valor valor) {
		super();
		this.palo = palo;
		this.valor = valor;
	}

	public Palo getPalo() {
		return palo;
	}

	public void setPalo(Palo palo) {
		this.palo = palo;
	}

	public Valor getValor() {
		return valor;
	}

	public void setValor(Valor valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		return "Carta [palo=" + palo + ", valor=" + valor + "]";
	}
	
	

}

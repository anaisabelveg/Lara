package com.ejercicio1;

public class TestFiguras {

	public static void main(String[] args) {
		Figura figura = new Figura(45, 89);
		Circulo circulo = new Circulo(23, 45, 2);
		Rectangulo rectangulo = new Rectangulo(23, 67, 24, 90);
		
		System.out.println(figura.posicion());
		System.out.println(circulo.posicion());
		System.out.println(rectangulo.posicion());

	}

}

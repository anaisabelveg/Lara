package com.ejercicio2;

public class Tren extends Vehiculo {

	private boolean mercancias;
	private int numVagones;

	public Tren(String tipo, int longitud, String combustible, boolean mercancias, int numVagones) {
		super(tipo, longitud, combustible);
		this.mercancias = mercancias;
		this.numVagones = numVagones;
	}

	public boolean isMercancias() {
		return mercancias;
	}

	public void setMercancias(boolean mercancias) {
		this.mercancias = mercancias;
	}

	public int getNumVagones() {
		return numVagones;
	}

	public void setNumVagones(int numVagones) {
		this.numVagones = numVagones;
	}

}

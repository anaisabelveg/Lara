package com.ejercicio2;

public class Vehiculo {

	private String tipo; // tierra,mar,aire
	private int longitud;
	private String combustible;

	public Vehiculo(String tipo, int longitud, String combustible) {
		super();
		this.tipo = tipo;
		this.longitud = longitud;
		this.combustible = combustible;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getLongitud() {
		return longitud;
	}

	public void setLongitud(int longitud) {
		this.longitud = longitud;
	}

	public String getCombustible() {
		return combustible;
	}

	public void setCombustible(String combustible) {
		this.combustible = combustible;
	}

}

package com.example;

public class AppMain {

	public static void main(String[] args) {
		
		Empleado e1 = new Empleado("Juan", 10000);
		System.out.println(e1);
		System.out.println("Contador: " + Empleado.getContador());
		
		Empleado e2 = new Empleado("Maria", 20000);
		System.out.println(e2);
		System.out.println("Contador: " + Empleado.getContador());
		
		Empleado e3 = new Empleado("Jorge", 30000);
		System.out.println(e3);
		System.out.println("Contador: " + Empleado.getContador());
		
	}

}

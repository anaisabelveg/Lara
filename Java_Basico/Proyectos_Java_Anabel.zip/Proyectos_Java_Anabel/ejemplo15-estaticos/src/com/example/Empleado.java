package com.example;

public class Empleado {
	
	// Variables de instancia
	// Por eso cada instancia tiene una copia de estas variables
	// Variable final -> una vex asignado un valor no se puede cambiar
	// Las variables finales se escriben en mayusculas
	private final int NUM_EMPLEADO;
	private String nombre;
	private double sueldo;
	
	// Variables de clase
	// Solo se guarda una copia de esta variable en la clase
	private static int contador;
	
	public Empleado() {
		// TODO Auto-generated constructor stub
		NUM_EMPLEADO = ++contador;
	}

	public Empleado(String nombre, double sueldo) {
		super();
		this.nombre = nombre;
		this.sueldo = sueldo;
		NUM_EMPLEADO = ++contador;
	}
	
	// Los metodos estaticos solo tienen una copia en la clase
	public static int getContador() {
		return contador;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	
	public int getNUM_EMPLEADO() {
		return NUM_EMPLEADO;
	}
	
	/*
	public void setNUM_EMPLEADO(int NUM_EMPLEADO) {
		this.NUM_EMPLEADO = NUM_EMPLEADO;
	}
	*/

	@Override
	public String toString() {
		return "Empleado [NUM_EMPLEADO=" + NUM_EMPLEADO +
				", nombre=" + nombre + ", sueldo=" + sueldo + "]";
	}
	

}

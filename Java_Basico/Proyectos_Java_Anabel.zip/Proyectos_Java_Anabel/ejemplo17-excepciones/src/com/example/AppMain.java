package com.example;

import java.util.Scanner;

public class AppMain {

	public static void main(String[] args)  {
		
		Operaciones op = new Operaciones();
		op.sumar(7, 0);
		try {
			op.dividir(7, 0);
		}catch (Dividir0Exception e) {
			System.out.println(e.getMessage());
		}
		
		int num = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce un numero");
		try {
			num = sc.nextInt();
		} catch(NumberFormatException ex) {
			System.out.println("El valor "+ num + " no es numerico");
		} catch(Exception ex) {
			System.out.println("Error capturado");
			System.out.println(ex.getClass());
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}	
		System.out.println(num);
		
		int suma = 0;
		for (String dato : args) {
			try {
				int numero = Integer.parseInt(dato);
				suma += numero;
			} catch(NumberFormatException ex) {
				System.out.println("El valor "+ dato + " no es numerico");
			}
			
		}
		
		System.out.println("Suma: " + suma);
	}

}


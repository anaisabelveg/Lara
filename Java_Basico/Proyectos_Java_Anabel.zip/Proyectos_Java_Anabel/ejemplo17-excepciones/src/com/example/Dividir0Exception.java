package com.example;

public class Dividir0Exception extends RuntimeException{

	public Dividir0Exception(String mensaje) {
		super(mensaje);
	}
	
}

package com.example;

public class Ejercicio4 {
	
	public static void main(String[] args) {
		char estado = 'C';
		
		switch (Character.toLowerCase(estado)) {
		case 's':
			System.out.println("Estas soltero");
			break;

		case 'c':
			System.out.println("Estas casado");
			break;
			
		case 'v':
			System.out.println("Estas viudo");
			break;
			
		case 'd':
			System.out.println("Estas divorciado");
			break;

		case 'p':
			System.out.println("Estas arrejuntado");
			break;

		default:
			System.out.println("No se reconoce tu estado");
			break;
		}
	}

}

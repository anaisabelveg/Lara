package com.example;

public class Circulo extends Figura {

	private double radio;

	public Circulo(int coordenadaX, int coordenadaY, double radio) {
		super(coordenadaX, coordenadaY);
		this.radio = radio;
	}

	@Override
	public double area() {
		// TODO Auto-generated method stub
		return Math.PI * Math.pow(radio, 2);
	}

	public double getRadio() {
		return radio;
	}

	public void setRadio(double radio) {
		this.radio = radio;
	}

}

package com.example;

public class Ejercicio4 {

	public static void main(String[] args) {
		// Escribir el factorial del numero 15
		
		long resultado = 1;
		for(int numero = 15; numero > 0; numero--) {
			//resultado = resultado * numero;
			resultado *= numero;
		}
		System.out.println("El factorial de 15 es " + resultado);

	}

}

package com.example;

public class Ejercicio5 {

	public static void main(String[] args) {
		// Hallar 2 elevado a 8
		
		int resultado = 1;
		int numero = 2;
		
		for(int potencia = 1; potencia <= 8; potencia++) {
			resultado = resultado * numero;
		}
		
		System.out.println(resultado);

	}

}

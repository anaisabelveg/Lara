package com.example;

public class Ejercicio8 {

	public static void main(String[] args) {
		// Con los 20 primeros números decir con cada uno por cual es divisible:

		for (int numero = 1; numero<= 20; numero++) {
			
			
			for(int divisor = 1; divisor <= numero; divisor++) {
				if (numero % divisor == 0) {
					System.out.println( numero + " -> es divisible por: " +divisor );
				}
			}
		}
	}

}

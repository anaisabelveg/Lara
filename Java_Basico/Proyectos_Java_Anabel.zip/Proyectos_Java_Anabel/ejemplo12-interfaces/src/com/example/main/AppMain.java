package com.example.main;

import com.example.models.Pajaro;

public class AppMain {

	public static void main(String[] args) {
		Pajaro pajaro = new Pajaro("Piolin", "Canario", 2, "Americana");
		
		System.out.println(pajaro);

	}

}

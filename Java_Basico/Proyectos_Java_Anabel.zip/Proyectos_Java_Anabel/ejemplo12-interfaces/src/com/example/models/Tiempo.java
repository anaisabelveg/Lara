package com.example.models;

public interface Tiempo {
	
	int supervivenciaMax();

}

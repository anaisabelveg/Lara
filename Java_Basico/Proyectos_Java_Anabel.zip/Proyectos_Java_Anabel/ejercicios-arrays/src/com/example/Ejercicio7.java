package com.example;

public class Ejercicio7 {

	public static void main(String[] args) {
		// sume todas las componentes del array
		float[] decimales = new float[]{3.4F,5.67F,12.0F,3.141615F,0.0F};
		
		float resultado = 0;
		
		for (float numero : decimales) {
			resultado += numero;
		}
		
		System.out.println("Total: " + resultado);
	}

}

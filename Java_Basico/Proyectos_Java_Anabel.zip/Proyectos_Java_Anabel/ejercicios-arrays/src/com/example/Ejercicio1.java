package com.example;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Crear un bloque de código que pinte las vocales y 
		// solo las vocales que existen en un array de caracteres.
		char caracteres[] = {'6','a','d','u','-','z','i','t','b'};
		
		for (char caracter : caracteres) {
			switch (caracter) {
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':
					System.out.println(caracter);
			}
		}
	}

}

package com.example;

import java.util.Arrays;

public class Ejercicio2 {

	public static void main(String[] args) {
		// Crear un bloque de código que lea las componentes 
		// de un array de enteros y me pinte cuales con pares, 
		// cuales impares y cuales con múltiplos de tres

		int numeros[] = new int[] {5,2,9,7,1,4,6,8,3};
		
		for(int i=0; i<numeros.length; i++) {
			if (numeros[i] % 2 == 0) {
				System.out.println("El numero " + numeros[i] + " es par");
			} else {
				System.out.println("El numero " + numeros[i] + " es impar");
			}
			
			if (numeros[i] % 3 == 0) {
				System.out.println("El numero " + numeros[i] + " es multiplo de 3");
			} else {
				System.out.println("El numero " + numeros[i] + " no es multiplo de 3");
			}
		}
		
		int pares[] = new int[numeros.length];
		int impares[] = new int[numeros.length];
		int multiplo3[] = new int[numeros.length];
		
		int c_pares = 0, c_impares = 0, c_multiplos = 0;
		
		for(int numero : numeros) {
			if (numero % 2 == 0) {
				pares[c_pares] = numero;
				c_pares++;
			} else {
				impares[c_impares] = numero;
				c_impares++;
			}
			
			if (numero % 3 == 0) {
				multiplo3[c_multiplos] = numero;
				c_multiplos++;
			}
		}
		
		System.out.println("Pares: " + Arrays.toString(pares));
		System.out.println("Impares: " + Arrays.toString(impares));
		System.out.println("Multiplos: " + Arrays.toString(multiplo3));
		
	}

}






package com.example;

import java.util.Arrays;

public class Ejercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array1[][] = {{ 1, 2},{ 0, 5}};
		int array2[][] = new int[2][2];
		array2[0][0] = 3;
		array2[0][1] = 4;
		array2[1][0] = 5;
		array2[1][1] = 8;
		
		int resultado[][] = new int[2][2];
		
		for(int fila=0; fila<array1.length; fila++) {
			for (int columna=0; columna<array1[fila].length; columna++) {
				resultado[fila][columna] = array1[fila][columna] + array2[fila][columna];
			}
		}
		
		System.out.println(Arrays.deepToString(resultado));
		
		for (int[] fila : resultado) {
			for (int numero : fila) {
				System.out.print(numero + "\t");
			}
			System.out.println();
		}
	}

}







package com.example;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeSet;

import com.example.comparators.NombreComparator;
import com.example.comparators.NotaComparator;
import com.example.models.Alumno;
import com.example.models.AlumnoComparable;

public class AppMain {

	public static void main(String[] args) {

		// Arbol de numeros
		Set<Integer> numeros = new TreeSet<>();
		numeros.add(6);
		numeros.add(1);
		numeros.add(8);
		numeros.add(9);
		numeros.add(2);
		numeros.add(5);
		numeros.add(4);
		System.out.println(numeros);

		Set<String> colores = new TreeSet<>();
		colores.add("rojo");
		colores.add("verde");
		colores.add("azul");
		colores.add("negro");
		colores.add("amarillo");
		System.out.println(colores);

		// Arbol de alumnos
		Set<AlumnoComparable> alumnos = new TreeSet<>();
		alumnos.add(new AlumnoComparable(1, "Juan", "Perez", 7.5));
		alumnos.add(new AlumnoComparable(4, "Marta", "Rodriguez", 6.1));
		alumnos.add(new AlumnoComparable(2, "Pedro", "Sanz", 9.2));
		alumnos.add(new AlumnoComparable(6, "Angel", "Lara", 4.3));
		alumnos.add(new AlumnoComparable(5, "Jose", "Sanchez", 8.3));
		alumnos.add(new AlumnoComparable(3, "Laura", "Lopez", 5.7));
		System.out.println(alumnos);

		// Recorrer un arbol
		for (Object alum : alumnos.toArray()) {
			System.out.println(alum);
		}

		// Arbol de alumnos
		// Set<Alumno> alumnos2 = new TreeSet<>(new NotaComparator());
		Set<Alumno> alumnos2 = new TreeSet<>(new NombreComparator());
		alumnos2.add(new Alumno(1, "Juan", "Perez", 7.5));
		alumnos2.add(new Alumno(4, "Marta", "Rodriguez", 6.1));
		alumnos2.add(new Alumno(2, "Pedro", "Sanz", 9.2));
		alumnos2.add(new Alumno(6, "Angel", "Lara", 4.3));
		alumnos2.add(new Alumno(5, "Jose", "Sanchez", 8.3));
		alumnos2.add(new Alumno(3, "Laura", "Lopez", 5.7));
		System.out.println(alumnos2);

		// Recorrer un arbol
		for (Object alum : alumnos2.toArray()) {
			System.out.println(alum);
		}

		// Java permite instanciar una interface o clase abstracta
		// si en ese momento implementas los metodos abstractos
		Set<Alumno> alumnos3 = new TreeSet<>(new Comparator<Alumno>() {

			@Override
			public int compare(Alumno alum1, Alumno alum2) {
				// TODO Auto-generated method stub
				return alum1.getApellido().compareTo(alum2.getApellido());
			}
		});
		alumnos3.add(new Alumno(1, "Juan", "Perez", 7.5));
		alumnos3.add(new Alumno(4, "Marta", "Rodriguez", 6.1));
		alumnos3.add(new Alumno(2, "Pedro", "Sanz", 9.2));
		alumnos3.add(new Alumno(6, "Angel", "Lara", 4.3));
		alumnos3.add(new Alumno(5, "Jose", "Sanchez", 8.3));
		alumnos3.add(new Alumno(3, "Laura", "Lopez", 5.7));
		System.out.println(alumnos3);

		// Recorrer un arbol
		for (Object alum : alumnos3.toArray()) {
			System.out.println(alum);
		}
	}

}

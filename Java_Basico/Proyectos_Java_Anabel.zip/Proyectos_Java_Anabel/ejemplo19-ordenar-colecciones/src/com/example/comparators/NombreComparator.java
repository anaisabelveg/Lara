package com.example.comparators;

import java.util.Comparator;

import com.example.models.Alumno;

public class NombreComparator implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// TODO Auto-generated method stub
		return alum1.getNombre().compareTo(alum2.getNombre());
	}

}

package com.example.comparators;

import java.util.Comparator;

import com.example.models.Alumno;

public class NotaComparator implements Comparator<Alumno>{

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// 0 si los alumnos son iguales
		// 1 si el alumno es mayor que otro
		// -1 si el alumno es menor que otro
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		} else {
			return 0;
		}
		
	}

}

package vegas.anabel;

import vegas.anabel.models.Cliente;
import vegas.anabel.models.Direccion;
import vegas.anabel.models.Factura;
import vegas.anabel.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear una factura
		Factura factura1 = new Factura();
		
		// Agregar el cliente a la factura
		factura1.cliente = new Cliente();
		factura1.cliente.nombre = "Juan";
		factura1.cliente.cif = "B-12345678";
		
		// Agregar una direccion al cliente de nuestra factura
		factura1.cliente.direccion = new Direccion();
		factura1.cliente.direccion.calle = "Piscis";
		factura1.cliente.direccion.numero = 3;
		factura1.cliente.direccion.poblacion = "Madrid";
		
		factura1.numero = 1;
		factura1.concepto = "Venta de material deportivo";
		
		// Agregar el producto a la factura
		factura1.producto = new Producto();
		
		factura1.producto.ID = 1;
		factura1.producto.descripcion = "Zapatillas Puma";
		factura1.producto.precio = 89.45;
		
		System.out.println(factura1);
		
		Factura factura2 = new Factura(
				new Cliente("Pepe", "B-98765432", 
						new Direccion("Mayor", 34, "Madrid")), 
				2, "Reparacion", new Producto(2, "Lavadora", 78));
		System.out.println(factura2);

	}

}











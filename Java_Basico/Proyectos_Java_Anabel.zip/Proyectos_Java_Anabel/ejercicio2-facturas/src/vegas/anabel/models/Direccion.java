package vegas.anabel.models;

public class Direccion {

	public String calle;
	public int numero;
	public String poblacion;
	
	public Direccion() {
		// TODO Auto-generated constructor stub
	}
	
	

	public Direccion(String calle, int numero, String poblacion) {
		super();
		this.calle = calle;
		this.numero = numero;
		this.poblacion = poblacion;
	}



	@Override
	public String toString() {
		return "Direccion [calle=" + calle + ", numero=" + numero + ", poblacion=" + poblacion + "]";
	}

}

package vegas.anabel.models;

public class Factura {

	public Cliente cliente;
	public int numero;
	public String concepto;
	public Producto producto;

	public Factura() {
		// TODO Auto-generated constructor stub
	}

	public Factura(Cliente cliente, int numero, String concepto, Producto producto) {
		super();
		this.cliente = cliente;
		this.numero = numero;
		this.concepto = concepto;
		this.producto = producto;
	}

	@Override
	public String toString() {
		return "Factura [cliente=" + cliente + ", numero=" + numero + ", concepto=" + concepto + ", producto="
				+ producto + "]";
	}

}

package com.example;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Calcular el factorial de 25
		
		float resultado = 1;
		int numero = 25;
		while (numero > 1) {
			resultado = resultado * numero;
			numero--;
		}
		System.out.println("25! = " + resultado);

	}

}

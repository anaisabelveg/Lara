package com.example;

public class Ejercicio2 {

	public static void main(String[] args) {
		// Calcular la potencia de 2 elevado a 8
		int numero = 2;
		int resultado = 1;
		int potencia = 1;
		
		while (potencia <= 8) {
			resultado = resultado * numero;
			potencia++;
		}
		System.out.println("2^8 = " + resultado);
	}

}

package com.example;

public class AppMain {

	public static void main(String[] args) {
		
		// Polimorfismo
		// Es la habilidad de ver el mismo objeto de multiples formas
		
		// Aqui lo veo como un director
		Director director = new Director("Pepe", 40000, 5000, "1234-LDB");
		director.setBonus(4000);
		System.out.println(director);
		
		// Aqui lo veo como un empleado
		Empleado empleado = new Director("Pepe", 40000, 5000, "1234-LDB");
		//empleado.setSueldo(30000);
		
		// Aqui lo veo como un objeto
		Object objeto = new Director("Pepe", 40000, 5000, "1234-LDB");
		//objeto.setCoche("8765-HBD");
		System.out.println(objeto.toString());
		
		// ¿ Como puedo cambiar la forma de ver un objeto?
		// A traves de casting de objetos
		Director dire = (Director) objeto;
		dire.setCoche("8765-HBD");
		
		Empleado empl = (Empleado) objeto;
		empl.setSueldo(35000);
		
		// No puedo hacer un casting a una clase de la cual
		// no es objeto
		// Devuelve un ClassCastException
		Empleado e = new Empleado("Maria", 60000);
		//Director d = (Director)e;
		
		// Igualdad de objetos
		System.out.println("Son iguales con == " + (empleado == director));
		System.out.println("Son iguales con equals " + (empleado.equals(director)));
		
		System.out.println("Son iguales con equals " + (director.equals(e)));
		
		System.out.println(empleado.hashCode());
		System.out.println(director.hashCode());
		System.out.println(e.hashCode());
	}
 
}


















package com.example;

public class Director extends Gerente{

	

	private String coche;
	

	public Director(String nombre, double sueldo, double bonus, String coche) {
		super(nombre, sueldo, bonus);
		this.coche = coche;
	}

	public String getCoche() {
		return coche;
	}

	public void setCoche(String coche) {
		this.coche = coche;
	}

	@Override
	public String toString() {
		return " coche=" + coche + super.toString();
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((coche == null) ? 0 : coche.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Director other = (Director) obj;
		if (coche == null) {
			if (other.coche != null)
				return false;
		} else if (!coche.equals(other.coche))
			return false;
		return true;
	}
	
}

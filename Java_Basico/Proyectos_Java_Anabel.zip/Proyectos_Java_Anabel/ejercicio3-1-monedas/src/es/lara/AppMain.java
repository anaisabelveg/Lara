package es.lara;

public class AppMain {

	public static void main(String[] args) {
		
		Monedas monedas = new Monedas();
		monedas.devolverCambio(500, 63.27);
		

	}

}

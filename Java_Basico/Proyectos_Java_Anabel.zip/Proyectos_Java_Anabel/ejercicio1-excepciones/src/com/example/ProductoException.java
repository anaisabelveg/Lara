package com.example;

public class ProductoException extends Exception{

	public ProductoException(String mensaje) {
		super(mensaje);
	}
}

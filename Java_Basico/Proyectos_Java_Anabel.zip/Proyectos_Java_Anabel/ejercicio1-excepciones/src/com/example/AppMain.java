package com.example;

public class AppMain {

	public static void main(String[] args) throws ProductoException {
		Producto producto1 = new Producto(1, "Pantalla", -399, "HP", "16 pulgadas");
		
		try {
			producto1.comprobar();
		} catch (ProductoException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		//Producto producto2 = new Producto(0, "Otra", 299, "HP", "14 pulgadas");
		//producto2.comprobar();
		
		System.out.println("Ver que esto no lo imprime");

	}

}
package com.example;

public class Producto {
	
	
	private int id;
	private String nombre;
	private double precio;
	private String proveedor;
	private String descripción;
	
	public Producto() {
		// TODO Auto-generated constructor stub
	}
	
	public Producto(int id, String nombre, double precio, String proveedor, 
			String descripción) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.precio = precio;
		this.proveedor = proveedor;
		this.descripción = descripción;	
	}

	public void comprobar() throws ProductoException {
		if (id <= 0) {
			throw new ProductoException("Este producto no tiene un ID");
		}
		

//		También comprobaremos mediante aserciones que el precio introducido es mayor que
//		0.
		//if (precio > 0 )
		assert (precio >= 0) : "El precio debe ser mayor que cero";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getProveedor() {
		return proveedor;
	}

	public void setProveedor(String proveedor) {
		this.proveedor = proveedor;
	}

	public String getDescripción() {
		return descripción;
	}

	public void setDescripción(String descripción) {
		this.descripción = descripción;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", nombre=" + nombre + ", precio=" + precio + ", proveedor=" + proveedor
				+ ", descripción=" + descripción + "]";
	} 
	
	

}

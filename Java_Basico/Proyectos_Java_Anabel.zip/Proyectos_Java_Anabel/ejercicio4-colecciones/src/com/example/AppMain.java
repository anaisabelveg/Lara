package com.example;

import java.util.HashMap;
import java.util.Map;

public class AppMain {

	public static void main(String[] args) {
//		Cree un programa que almacene la nota de una asignatura de varios alumnos en una
//		colección de tipo Map. El alumno se identificará por su nombre.
//		Cada elemento del mapa estará formado por nombre de tipo String y nota de tipo
//		Integer. Utilizar tipos genéricos.

		Map<String, Integer> alumnos = new HashMap<>();
		alumnos.put("Jorge", 9);
		alumnos.put("Juana", 5);
		alumnos.put("Julian", 8);
		alumnos.put("Jose", 7);
		
		for (String nombre : alumnos.keySet()) {
			if (alumnos.get(nombre) >= 5) {
				System.out.println(nombre + ", aprobado");
			} else {
				System.out.println(nombre + ", suspenso");
			}
		}
	}

}




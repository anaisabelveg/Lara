package com.example;

public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int numero = 7;
		Integer objectInteger = numero;  //Autoboxing
		
		objectInteger.intValue();
		
		String texto = "12345";
		// Convertir el texto a un numero
		int miNumero = Integer.parseInt(texto);
		
		System.out.println(miNumero * 2);
		
		// Ademas tenemos .....
		System.out.println(Float.parseFloat(texto) * 30 ) ;
		Long.parseLong(texto);
		Double.parseDouble(texto);
		Short.parseShort(texto);
		Byte.parseByte(texto);
	}

}











package com.example;

import java.util.HashSet;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
//		Cree una clase que tenga un objeto de la clase HashSet, que añada varias cadenas al
//		objeto e imprima todas las cadenas. Utilizar el tipo genérico String.
		
		Set<String> cadenas = new HashSet<>();
		cadenas.add("Jorge");
		cadenas.add("Juan");
		cadenas.add("Ana");
		cadenas.add("Paula");
		System.out.println(cadenas);
		
	}

}

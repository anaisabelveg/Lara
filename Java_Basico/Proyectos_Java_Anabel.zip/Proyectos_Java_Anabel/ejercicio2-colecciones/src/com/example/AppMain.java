package com.example;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		// Cree un objeto de la clase ArrayList, añada una lista de cadenas y utilice un iterador
		// para imprimir las cadenas.
		
		List<String> lista = new ArrayList<>();
		lista.add("Jorge");
		lista.add("Juan");
		lista.add("Julian");
		lista.add("Juana");
		lista.add("Jimena");
		
		Iterator<String> iterador = lista.listIterator();
		while (iterador.hasNext()) {
			System.out.println(iterador.next());
		}

	}

}






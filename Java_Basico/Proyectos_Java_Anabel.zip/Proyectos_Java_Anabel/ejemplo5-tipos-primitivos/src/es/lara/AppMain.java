package es.lara;

public class AppMain {
	
	public static void main(String[] args) {
		// numericos enteros 
		byte numByte = (byte)7;
		short numShort = (short)56;
		int numEntero = 456;
		long numLong = 899766L;
		
		// numericos decimales
		float numFloat = 67886.34F;
		double numDouble = 6567764322.566;
		
		// logicos
		boolean boleano = true;
		
		// char
		char caracter = 't';
	
	
	}

}

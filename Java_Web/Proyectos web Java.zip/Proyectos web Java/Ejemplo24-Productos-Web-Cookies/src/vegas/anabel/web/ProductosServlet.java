package vegas.anabel.web;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vegas.anabel.bussines.Carrito;
import vegas.anabel.bussines.ProductosBS;
import vegas.anabel.models.Producto;

/**
 * Servlet implementation class ProductosServlet
 */
//@WebServlet("/ProductosServlet")
public class ProductosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		// Recuperar los parametros iniciales del Servlet
		String mensajeOferta = config.getInitParameter("Oferta");
				
		// recuperar el contexto de la aplicacion
		ServletContext appCtx = config.getServletContext();
		
		// Guardamos el mensaje como atributo de aplicacion
		appCtx.setAttribute("mensaje", mensajeOferta);
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ProductosServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// Recuperar el valor de op y asi ver que solicita el cliente
		String opcion = request.getParameter("op");
		ProductosBS productosBS = new ProductosBS();
		String vista = "/index.jsp";

		switch (opcion) {
		case "1":
			// Mostrar todos los productos
			List<Producto> lista = productosBS.consultarTodos();

			// Guardar la lista de productos como un atributo de peticion
			request.setAttribute("catalogo", lista);

			// Elegir la vista que mostrara el resultado
			vista = "/mostrarCatalogo.jsp";
			break;

		case "2":
			// Buscar un producto
			int id = Integer.parseInt(request.getParameter("codigo"));
			Producto producto = productosBS.buscar(id);
			request.setAttribute("producto", producto);
			vista = "/mostrarProducto.jsp";
			break;

		case "3":
			request.setAttribute("catalogo", productosBS.buscar(request.getParameter("descParam")));
			vista = "/mostrarCatalogo.jsp";
			break;

		case "4":
			Producto nuevo = new Producto(request.getParameter("descParam"),
					Double.parseDouble(request.getParameter("precioParam")));
			productosBS.insertar(nuevo);
			request.setAttribute("msg", "Producto insertado en la BBDD");
			vista = "/mostrarMensaje.jsp";
			break;

		case "5":
			id = Integer.parseInt(request.getParameter("codigo"));
			productosBS.eliminar(id);
			request.setAttribute("msg", "Producto eliminado de la BBDD");
			vista = "/mostrarMensaje.jsp";
			break;

		case "6":
			id = Integer.parseInt(request.getParameter("codigo"));
			double precio = Double.parseDouble(request.getParameter("precio"));
			productosBS.modificar(id, precio);
			request.setAttribute("msg", "Producto modificado de la BBDD");
			vista = "/mostrarMensaje.jsp";
			break;

		case "7":
			boolean logado = false;
			
			// Recuperar las cookies
			Cookie[] todasCookies = request.getCookies();
			
			// Buscar la cookie con el nombre de usuario
			for (Cookie cookie : todasCookies) {
				if ("nombreUsuario".equals(cookie.getName())){
					logado = true;
					break;
				}
			}
			
			if (logado) {
				// si existe entonces procedemos a la compra
				// Recuperar la session del cliente
				HttpSession miSesion = request.getSession();

				// Recuperamos el carrito
				Carrito miCarro = (Carrito) miSesion.getAttribute("miCarro");
				
				if (miCarro == null) {
					// No existe y la creamos con el carrito dentro
					miCarro = new Carrito();
					miSesion.setAttribute("miCarro", miCarro);
				}
				
				// Recuperar el codigo del producto
				id = Integer.parseInt(request.getParameter("codigo"));
				
				// Agregarlo al carrito
				miCarro.agregarProducto(id);
				
				// Seleccionar la vista mostrarCarrito.jsp
				vista = "/mostrarCarrito.jsp";
			} else {
				// si no existe le mandamos a login.html
				vista = "/login.html";
			}		

			break;
			
		case "8":
			HttpSession miSesion2 = request.getSession(false);
			Carrito miCarro2 = (Carrito) miSesion2.getAttribute("miCarro");
			id = Integer.parseInt(request.getParameter("codigo"));
			miCarro2.eliminarProducto(id);
			vista = "/mostrarCarrito.jsp";
			break;
			
		case "9":
			// Recuperar el nombre
			String nombreUsuario = request.getParameter("nombre");
			
			// Crear una cookie con ese nombre
			Cookie miCookie = new Cookie("nombreUsuario", nombreUsuario);
			miCookie.setMaxAge(5 * 60);  // 5 minutos
			
			// Adjuntar la cookie a la respuesta
			response.addCookie(miCookie);
			
			// devolver la vista
			vista = "/index.jsp";
			
		}

		RequestDispatcher rd = request.getRequestDispatcher(vista);
		// Paso de testigo, que continue la vista
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package vegas.anabel.web;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class MedirTiempoFilter
 */
//@WebFilter("/*")
public class MedirTiempoFilter implements Filter {

    /**
     * Default constructor. 
     */
    public MedirTiempoFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// Procesar la peticion

		// Tomar el tiempo
		long inicio = System.nanoTime();
		System.out.println("Medido tiempo de inicio -------");
		
		
		// pass the request along the filter chain
		chain.doFilter(request, response);
		
		// Procesar la respuesta
		long fin = System.nanoTime();
		System.out.println("Medido el tiempo final ------");
		System.out.println("Tiempo invertido en procesar la peticion " +
		    (fin - inicio) + " nanoSeg.");
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}

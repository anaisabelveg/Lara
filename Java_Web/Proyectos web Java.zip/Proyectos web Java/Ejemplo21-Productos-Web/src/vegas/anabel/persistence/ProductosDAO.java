package vegas.anabel.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vegas.anabel.models.Producto;

public class ProductosDAO {

	private Connection conexion;
	
	public void modificar(int id, double precio) {
		try {
			abrirConexion();
			String sql = "update Productos set PRECIO = ? where ID = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setDouble(1, precio);
			pst.setInt(2, id);
			int filas = pst.executeUpdate();
			System.out.println(filas + " registros modificados");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	public void eliminar(int id) {
		try {
			abrirConexion();
			String sql = "delete from Productos where ID = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			int filas = pst.executeUpdate();
			System.out.println(filas + " registros eliminado");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	public void alta(Producto nuevo) {
		try {
			abrirConexion();
			String sql = "insert into Productos (DESCRIPCION, PRECIO) values (?,?)";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setString(1, nuevo.getDescripcion());
			pst.setDouble(2, nuevo.getPrecio());
			int filas = pst.executeUpdate();
			System.out.println(filas + " registros insertados");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}

	public List<Producto> buscarPorDescripcion(String descripcion) {

		List<Producto> encontrados = new ArrayList<>();

		try {
			abrirConexion();
			String sql = "select * from Productos where DESCRIPCION like ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setString(1, "%"+descripcion+"%");
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				encontrados.add(new Producto(rs.getInt("ID"), 
						rs.getString("DESCRIPCION"), rs.getDouble("PRECIO")));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}

		return encontrados;
	}
	
	public Producto buscarPorId(int id) {

		Producto encontrado = new Producto();

		try {
			abrirConexion();
			String sql = "select * from Productos where ID = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				encontrado = new Producto(rs.getInt("ID"), 
						rs.getString("DESCRIPCION"), rs.getDouble("PRECIO"));
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			cerrarConexion();
		}

		return encontrado;
	}

	public List<Producto> todos() {

		List<Producto> lista = new ArrayList<Producto>();

		try {
			abrirConexion();
			Statement stm = conexion.createStatement();
			ResultSet rs = stm.executeQuery("select * from Productos");
			while (rs.next()) {
				lista.add(new Producto(rs.getInt("ID"), rs.getString("DESCRIPCION"), rs.getDouble("PRECIO")));
			}
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			cerrarConexion();
		}

		return lista;
	}

	private void abrirConexion() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/LaraDB", "root", "");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void cerrarConexion() {
		try {
			conexion.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package vegas.anabel.modelos;

import java.util.Date;

public class Alumno {

	private int ID;
	private String nombre;
	private String apellido;
	private Date fechaNacimiento;
	private boolean repetidor;
	private double nota;
	
	public Alumno() {
		// TODO Auto-generated constructor stub
	}

	public Alumno(int iD, String nombre, String apellido, Date fechaNacimiento, boolean repetidor, double nota) {
		super();
		ID = iD;
		this.nombre = nombre;
		this.apellido = apellido;
		this.fechaNacimiento = fechaNacimiento;
		this.repetidor = repetidor;
		this.nota = nota;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public boolean isRepetidor() {
		return repetidor;
	}

	public void setRepetidor(boolean repetidor) {
		this.repetidor = repetidor;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alumno [ID=" + ID + ", nombre=" + nombre + ", apellido=" + apellido + ", fechaNacimiento="
				+ fechaNacimiento + ", repetidor=" + repetidor + ", nota=" + nota + "]";
	}
	
	

}

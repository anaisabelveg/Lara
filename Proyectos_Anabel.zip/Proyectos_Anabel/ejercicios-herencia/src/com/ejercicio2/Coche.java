package com.ejercicio2;

public class Coche extends Vehiculo{
	
	private int cilindrada;

	public Coche(String tipo, int longitud, String combustible, int cilindrada) {
		super(tipo, longitud, combustible);
		this.cilindrada = cilindrada;
	}

	public int getCilindrada() {
		return cilindrada;
	}
	
	public void setCilindrada(int cilindrada) {
		this.cilindrada = cilindrada;
	}

}

package com.ejercicio2;

public class Barco extends Vehiculo {

	private int nudos;
	private String modo; // Motor o vela

	public Barco(String tipo, int longitud, String combustible, int nudos, String modo) {
		super(tipo, longitud, combustible);
		this.nudos = nudos;
		this.modo = modo;
	}

	public int getNudos() {
		return nudos;
	}

	public void setNudos(int nudos) {
		this.nudos = nudos;
	}

	public String getModo() {
		return modo;
	}

	public void setModo(String modo) {
		this.modo = modo;
	}

}

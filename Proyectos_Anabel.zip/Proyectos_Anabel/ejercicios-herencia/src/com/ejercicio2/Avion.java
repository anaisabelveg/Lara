package com.ejercicio2;

public class Avion extends Vehiculo{
	
	private boolean esPrivado;

	public boolean isEsPrivado() {
		return esPrivado;
	}

	public void setEsPrivado(boolean esPrivado) {
		this.esPrivado = esPrivado;
	}

	public Avion(String tipo, int longitud, String combustible, boolean esPrivado) {
		super(tipo, longitud, combustible);
		this.esPrivado = esPrivado;
	}
	
	

}

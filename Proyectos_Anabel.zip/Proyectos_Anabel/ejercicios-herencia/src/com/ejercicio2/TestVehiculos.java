package com.ejercicio2;

public class TestVehiculos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coche coche = new Coche("tierra", 4, "Gasolina", 1900);
		Barco barco = new Barco("mar", 400, "Diesel", 2000, "Motor");
		Tren tren = new Tren("tierra", 800, "Electrico", true, 6);
		Avion avion = new Avion("aire", 600, "Diesel", false);

	}

}

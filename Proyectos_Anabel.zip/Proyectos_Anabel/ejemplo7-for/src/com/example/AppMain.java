package com.example;

public class AppMain {

	public static void main(String[] args) {
		
		int i = 1;
		
		for(i = 1; i <= 10; ++i) {
			System.out.println(i);
		}
		
		int a = 7;
		int b = a++;
		System.out.println(b);
		
		int c = 7;
		int d = ++c;
		System.out.println(d);

	}

}

package com.example;

public class Director extends Gerente{

	private String coche;
	

	public Director(String nombre, double sueldo, double bonus, String coche) {
		super(nombre, sueldo, bonus);
		this.coche = coche;
	}

	public String getCoche() {
		return coche;
	}

	public void setCoche(String coche) {
		this.coche = coche;
	}

	@Override
	public String toString() {
		return " coche=" + coche + super.toString();
	}
	
	
	
}

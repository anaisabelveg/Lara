package com.example;

public class AppMain {

	public static void main(String[] args) {
		
		
//		Director director = new Director();
//		director.setNombre("Pepe");
//		director.setSueldo(40_000);
//		director.setBonus(5000);
//		director.setCoche("1234-LDZ");
		
		
		Director director = new Director("Pepe", 40000, 5000, "1234-LDZ");
		
		System.out.println(director);
		
		
		Empleado empleado = new Empleado("Juan");
		System.out.println(empleado);
		
		
		
	}

}






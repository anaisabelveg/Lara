package com.example;

public class Empleado {

	private String nombre;
	private double sueldo;
	
	
	public Empleado(String nombre) {
		// Si pongo una llamada this() no puedo tener otra super()
		// y viceversa
		//super();
		this(nombre, 18000);
	}

	public Empleado(String nombre, double sueldo) {
		// La llamada super() o this() debe ser la primera linea del constructor
		super();
		this.nombre = nombre;
		this.sueldo = sueldo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return " nombre=" + nombre + " sueldo=" + sueldo;
	}

	

	
}












package com.example;

public class AppMain {

	public static void main(String[] args) {
		
		int numero = 1;
		while(numero <= 10) {
			System.out.println(numero);
			numero++;
		}
		
		
		numero = 1;
		do {
			System.out.println(numero);
			numero++;
		} while(numero <= 10);
	}

}

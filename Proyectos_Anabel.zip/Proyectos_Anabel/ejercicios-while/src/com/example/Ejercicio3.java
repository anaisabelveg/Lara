package com.example;

public class Ejercicio3 {

	public static void main(String[] args) {
		// Calcular los 25 primeros números primos, NO DEL 1 AL 25
		
		// Variable que lleva la cuenta de los numeros primos encontrados
		// al llegar a 25 paramos
		int contador = 0;
		
		// Variable para ir recorriendo los posibles numeros primos
		int numero = 1;

		System.out.println("Los 25 primeros numeros primos son:");
		while(contador < 25) {
			// Todo numero es primo salvo que se demuestre lo contrario
			boolean esPrimo = true;
			
			/*
			int divisor = 2;
			while(divisor<numero && esPrimo) {
				if (numero % divisor == 0) {
					esPrimo = false;
				}
				divisor++;
			}
			*/
				
			for(int divisor = 2;  divisor<numero; divisor++) {
				if (numero % divisor == 0) {
					esPrimo = false;
					break;  // Damos por terminado el bucle for
				}
			} // fin for 
			
			
			if (esPrimo) {
				System.out.println(numero);
				contador++;
			} // fin if
			
			// Probamos el siguiente numero
			numero++;
		} // fin while
	} // fin main

} // fin clase








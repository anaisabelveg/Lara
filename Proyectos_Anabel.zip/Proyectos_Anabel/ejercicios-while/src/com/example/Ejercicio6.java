package com.example;

public class Ejercicio6 {

	public static void main(String[] args) {
		// Calcular los n primeros términos de la serie de Fibonacci
		
		
		int primero = 0;
		int segundo = 1;
		int resultado = 0;
		
		System.out.println(primero);
		System.out.println(segundo);
		
		int n = 3;
		while(n <= 10) {
			resultado = primero + segundo;
			System.out.println(resultado);
			
			primero = segundo;
			segundo = resultado;
			n++;
		}

	}

}

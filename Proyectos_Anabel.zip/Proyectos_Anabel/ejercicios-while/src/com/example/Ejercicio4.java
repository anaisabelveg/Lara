package com.example;

public class Ejercicio4 {

	public static void main(String[] args) {
		// Encontrar el primer número primo a partir de 198
		
		boolean encontrado = false;
		int numero = 198;
		
		while(encontrado == false) {
			
			boolean esPrimo = true;
			
			for(int divisor = 2;  divisor<numero; divisor++) {
				if (numero % divisor == 0) {
					esPrimo = false;
					break;  // Damos por terminado el bucle for
				}
			} // fin for 
			
			if (esPrimo) {
				System.out.println("El numero primo es " + numero);
				encontrado = true;
			} else {
				numero++;
			}
					
		}
	}

}

package vegas.anabel.models;

public class Cliente {

	public String nombre;
	public String cif;
	public Direccion direccion;
	
	public Cliente() {
		// TODO Auto-generated constructor stub
	}


	public Cliente(String nombre, String cif, Direccion direccion) {
		super();
		this.nombre = nombre;
		this.cif = cif;
		this.direccion = direccion;
	}



	@Override
	public String toString() {
		return "Cliente [nombre=" + nombre + ", cif=" + cif + ", direccion=" + direccion + "]";
	}

}

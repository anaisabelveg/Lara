package aa;

import bb.ClaseB;

public class ClaseA {
	
	public void probarAccesos() {
		ClaseB obj = new ClaseB();
		obj.publica = "Solo acceso a la publica";
	}

}

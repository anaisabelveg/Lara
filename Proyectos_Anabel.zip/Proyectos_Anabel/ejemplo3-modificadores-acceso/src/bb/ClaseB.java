package bb;

public class ClaseB {
	
	public String publica;
	private String privada;
	protected String protegida;
	String defecto;

}

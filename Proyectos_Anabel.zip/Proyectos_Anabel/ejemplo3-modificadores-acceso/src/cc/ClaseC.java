package cc;

import bb.ClaseB;

public class ClaseC extends ClaseB{
	
	// Los recursos que no son privados se heredan
	
	public void probarAccesos() {
		
		publica = "Tengo acceso a la publica";		
		protegida = "Permitido por ser subclase de ClaseB";
	}

}

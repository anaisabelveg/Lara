package com.example.models;

public class SerVivo implements Habitat, Tiempo {

	@Override
	public int supervivenciaMax() {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public String clima() {
		// TODO Auto-generated method stub
		return "Humedo";
	}
	
	public void respira() {
		System.out.println("El ser vivo respira");
	}
	
	public void come() {
		System.out.println("El ser vivo come");
	}
	
	public void reproduce() {
		System.out.println("El ser vivo se reproduce");
	}
	
	public void muere() {
		System.out.println("El ser vivo muere");
	}

}

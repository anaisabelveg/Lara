package com.example.models;

public class Pajaro extends Animal implements Sonidos {

	private String especie;

	public Pajaro() {
		// TODO Auto-generated constructor stub
	}

	public Pajaro(String nombre, String raza, int edad, String especie) {
		super(nombre, raza, edad);
		this.especie = especie;
	}

	@Override
	public String sonido() {
		// TODO Auto-generated method stub
		return "Pio pio";
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	@Override
	public String toString() {
		return "Pajaro [especie=" + especie + ", toString()=" + super.toString() + "]";
	}

}

package com.example.models;

public interface Habitat {
	
	String clima();

}

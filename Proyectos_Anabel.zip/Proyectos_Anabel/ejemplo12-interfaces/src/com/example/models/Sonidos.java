package com.example.models;

public interface Sonidos {
	
	String sonido();

}

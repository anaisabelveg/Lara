package com.example.main;

import com.example.models.Cliente;
import com.example.models.Direccion;

public class AppMain {

	public static void main(String[] args) {
		
		// Crear instancia u objeto de Cliente
	   Cliente cliente1	= new Cliente();
	   
	   // Dar datos al objeto
	   cliente1.ID = 1;
	   cliente1.nombre = "Juan";
	   cliente1.cif = "12345678-A";
	   cliente1.telefono = "656123456";
	   cliente1.email = "juan@gmail.com";
	   cliente1.sexo = 'H';
	   cliente1.esVip = true;
	   
	   cliente1.direccion = new Direccion();
	   //cliente1.direccion = null;
	   
	   cliente1.direccion.calle = "Piscis";
	   cliente1.direccion.numero = 28;
	   cliente1.direccion.piso = 4;
	   cliente1.direccion.letra = 'B';
	   cliente1.direccion.codigoPostal = 28030;
	   cliente1.direccion.poblacion = "Madrid";
	   cliente1.direccion.provincia = "Madrid";
	   cliente1.direccion.pais = "España";
	   
	   
	   // Llamadas a los metodos
	   cliente1.cambiarEmail("nuevo@gmail.com");
	   
	   System.out.println(cliente1.dameTelefono());
	   

	}

}












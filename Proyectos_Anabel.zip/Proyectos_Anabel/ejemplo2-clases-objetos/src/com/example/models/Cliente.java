package com.example.models;

public class Cliente {
	
	// atributos o propiedades
	// variables globales
	public int ID;
	public String nombre;
	public String cif;
	public String telefono;
	public Direccion direccion;
	public String email;
	public char sexo;
	public boolean esVip;
	
	// acciones o metodos
	public void cambiarEmail(String nuevo) {
		email = nuevo;
	}
	
	public String dameTelefono() {
		// .....
		return telefono;
	}
}

















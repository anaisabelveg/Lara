package com.example;

public class MisArrays {

	public static void main(String[] args) {
		// Declarar un array
		int numeros1[] = null;
		int[] numeros2 = {1,2,3,7,6,5};
		int [] numeros3 = null;
		
		// Crear el array
		numeros1 = new int[6];
		// numeros2 = {1,2,3,7,6,5};  error-> no me lo permite
		numeros3 = new int[]{1, 2, 3, 7, 6, 5};
		
		// Asignar valores a un array
		numeros1[0] = 6;
		numeros1[1] = 7;
		numeros1[2] = 3;
		numeros1[3] = 2;
		numeros1[4] = 8;
		numeros1[5] = 4;
		
		// Recorrer un array con for tradicional
		for(int i=0; i<numeros1.length; i++) {
			System.out.println(numeros1[i]);
		}
		
		// Recorrer un array con for-each
		for (int numero : numeros3) {
			System.out.println(numero);
		}
		
	}

}










package com.example;

import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
		
		// solicitar datos por teclado
		Scanner sc = new Scanner(System.in);
		System.out.println("Escribe el dia de la semana");
		char dia = sc.next().charAt(0);
		
		sc.close();
		
		switch (dia) {
		case 'l':
		case 'L':
			System.out.println("Hoy es lunes");
			break;
			
		case 'm':
		case 'M':
			System.out.println("Hoy es martes");
			break;	
			
		case 'x':
		case 'X':
			System.out.println("Hoy es miercoles");
			break;
			
		case 'j':
		case 'J':
			System.out.println("Hoy es jueves");
			break;
			
		case 'v':
		case 'V':
			System.out.println("Hoy es viernes");
			break;
			
		case 's':
		case 'S':
			System.out.println("Hoy es sabado");
			break;
			
		case 'd':
		case 'D':
			System.out.println("Hoy es domingo");
			break;	

		default:
			System.out.println("Dia no reconocido");
			break;
		}

	}

}

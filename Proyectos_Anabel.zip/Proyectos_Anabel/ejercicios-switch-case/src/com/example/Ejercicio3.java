package com.example;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		int numero = 1230;
		
		// comprobar si es multiplo de 2
		switch (numero % 2) {
		case 0:
			System.out.println("El numero " + numero + " es divisible por 2" );
			break;

		default:
			System.out.println("El numero " + numero + " no es divisible por 2" );
			break;
		}
		
		// comprobar si es multiplo de 3
		switch (numero % 3) {
		case 0:
			System.out.println("El numero " + numero + " es divisible por 3" );
			break;

		default:
			System.out.println("El numero " + numero + " no es divisible por 3" );
			break;
		}
		
		// comprobar si es multiplo de 5
		switch (numero % 5) {
		case 0:
			System.out.println("El numero " + numero + " es divisible por 5" );
			break;

		case 1:
		case 2:
		case 3:
		case 4:
			System.out.println("El numero " + numero + " no es divisible por 5" );
			break;
		}
	}
}

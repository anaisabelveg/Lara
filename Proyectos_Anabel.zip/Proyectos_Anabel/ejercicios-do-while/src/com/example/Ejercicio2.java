package com.example;

public class Ejercicio2 {

	public static void main(String[] args) {
		// Resolver la serie de Fibonacci con do-while
		
		int primero = 0;
		int segundo = 1;
		int resultado = 0;
		
		System.out.println(primero);
		System.out.println(segundo);
		
		int n = 3;
		do{
			resultado = primero + segundo;
			System.out.println(resultado);
			
			primero = segundo;
			segundo = resultado;
			n++;
		}while(n <= 10);

	}

}

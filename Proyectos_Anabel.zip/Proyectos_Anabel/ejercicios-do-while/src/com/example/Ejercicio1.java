package com.example;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Resolver la potencia de 2 elevado a 8 con do-while
		
		int resultado = 1;
		int numero = 2;
		int potencia = 1;
		
		do {
			resultado *= numero;
			potencia++;
		} while(potencia <= 8);

		System.out.println("2^8 = " + resultado);
	}

}

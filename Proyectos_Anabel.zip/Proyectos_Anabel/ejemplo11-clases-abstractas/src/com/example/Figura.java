package com.example;

public abstract class Figura {

	private int coordenadaX;
	private int coordenadaY;
	
	public Figura(int coordenadaX, int coordenadaY) {
		super();
		this.coordenadaX = coordenadaX;
		this.coordenadaY = coordenadaY;
	}
	
	// Tengo un metodo declarado pero no implementado
	public abstract double area();

	public String posicion() {
		return "[" +  coordenadaX + "," + coordenadaY + "]";
	}

	public int getCoordenadaX() {
		return coordenadaX;
	}

	public void setCoordenadaX(int coordenadaX) {
		this.coordenadaX = coordenadaX;
	}

	public int getCoordenadaY() {
		return coordenadaY;
	}

	public void setCoordenadaY(int coordenadaY) {
		this.coordenadaY = coordenadaY;
	}

}

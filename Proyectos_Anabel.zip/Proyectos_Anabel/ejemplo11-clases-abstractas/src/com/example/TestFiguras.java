package com.example;

public class TestFiguras {

	public static void main(String[] args) {
		
		// Nunca puedo obtener un objeto de una clase abstracta
		// Solo me sirven como plantillas para herencia
		// o coo tipo de datos
		//Figura figura = new Figura(45, 89);
		Circulo circulo = new Circulo(23, 45, 2);
		Rectangulo rectangulo = new Rectangulo(23, 67, 24, 90);
		
		//System.out.println(figura.posicion());
		System.out.println("Posicion: " + circulo.posicion());
		System.out.println("Posicion: " + rectangulo.posicion());
		
		System.out.println("Area: " + circulo.area());
		System.out.println("Area: " + rectangulo.area());

	}

}

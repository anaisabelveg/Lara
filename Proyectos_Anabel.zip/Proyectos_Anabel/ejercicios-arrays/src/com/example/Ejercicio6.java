package com.example;

public class Ejercicio6 {

	public static void main(String[] args) {
		// que pinte, SOLO, las consonantes
	
		char[] letras = new char[]{'2','f','f','u','u','g','h','i','4'};
		
		for (char caracter : letras) {
			switch (caracter) {
				case 'a':
				case 'e':
				case 'i':
				case 'o':
				case 'u':
					break;
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				case '6':
				case '7':
				case '8':
				case '9':
				case '0':
					break;
				default:	
					System.out.println(caracter);
			}
		}

	}

}

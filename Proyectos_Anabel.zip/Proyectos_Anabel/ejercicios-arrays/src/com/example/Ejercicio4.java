package com.example;

import java.util.Arrays;

public class Ejercicio4 {

	public static void main(String[] args) {
		// Juntar los dos arrays en uno:
		// int[] array3 = new int[]{1,2,3,4,5,334,23,4};
		
		int[] array1 = new int[]{1,2,3,4,5};
		int[] array2 = new int[]{334,23,4};
		int[] array3 = new int[array1.length + array2.length];
		
		System.arraycopy(array1, 0, array3, 0, array1.length);
		System.arraycopy(array2, 0, array3, array1.length, array2.length);
		
		/*
		int contador = 0;
		for(int i=0; i< array1.length; i++) {
			array3[contador] = array1[i];
			contador++;
		}
		
		for(int i=0; i< array2.length; i++) {
			array3[contador] = array2[i];
			contador++;
		}
		*/
		
		System.out.println(Arrays.toString(array3));
	}

}



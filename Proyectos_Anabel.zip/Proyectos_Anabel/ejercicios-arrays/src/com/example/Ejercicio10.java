package com.example;

public class Ejercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] numeros = new int[][] { { 3, 4, 5, 78 }, { 0, 0, 0, 0 }, 
			{ 1, 1, 1, 1 }, { 6, 6, 6, -1 } };

		for (int[] fila : numeros) {
			for (int numero : fila) {
				System.out.print(numero + "\t");
			}
			System.out.println();
		}

	}

}

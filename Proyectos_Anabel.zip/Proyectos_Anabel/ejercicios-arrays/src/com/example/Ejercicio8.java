package com.example;

public class Ejercicio8 {

	public static void main(String[] args) {
		// sume por un lado solo los números pares y devuelva 
		// el resultado y por otro solo los impares
		
		int[] numeros = new int[]{1,2,7,3,4,65,23,78,98,34,342,45,57};
		
		int resultadoPares = 0;
		int resultadoImpares = 0;
		
		for (int numero : numeros) {
			if (numero % 2 == 0) {
				resultadoPares += numero;
			} else {
				resultadoImpares += numero;
			}
			
		}
		
		System.out.println("Total pares: " + resultadoPares);
		System.out.println("Total impares: " + resultadoImpares);
	}

}

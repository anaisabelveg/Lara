package com.example;

public class Ejercicio3 {
	
	public static void main(String[] args) {
		// Crear un bucle que pinte por consola todas las componentes 
		// de un array en orden inverso a como están guardadas en el array
		
		char caracteres[] = {'6','a','d','u','-','z','i','t','b'};
		
		for(int i=caracteres.length-1; i>=0; i--) {
			System.out.println(caracteres[i]);
		}
		
	}

}

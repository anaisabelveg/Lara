package com.example;

public class Ejercicio9 {

	public static void main(String[] args) {
		// Hallar la lista de los números primos hasta el 100

		numeros: for(int numero = 1; numero <= 100; numero++) {
			boolean esPrimo = true;
			
			for(int divisor = 2; divisor < numero; divisor++) {
				System.out.println("Probando divisor " + divisor + 
						"para numero " + numero);
				if (numero % divisor == 0) {
					esPrimo = false;
					continue numeros;
					//break;
				}
			}
			
			if (esPrimo) {
				System.out.println(numero);
			}
		}
	}

}

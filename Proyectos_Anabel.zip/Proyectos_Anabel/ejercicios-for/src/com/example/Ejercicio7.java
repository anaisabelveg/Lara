package com.example;

public class Ejercicio7 {
	
	public static void main(String[] args) {
		// Hallar todas las tablas de multiplicar con for anidados
		
		for(int numero = 1; numero <=10; numero++) {
			
			System.out.println("Tabla del " + numero);
			System.out.println("---------------------");
			
			for(int i = 1; i<= 10; i++) {
				System.out.println(numero + " x " + i + " = " + (numero * i));
			}
			
			System.out.println();
		}
	}

}

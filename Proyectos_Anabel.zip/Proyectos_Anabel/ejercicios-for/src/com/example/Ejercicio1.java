package com.example;

public class Ejercicio1 {

	public static void main(String[] args) {
		// Escribir los 10 primeros números (ascendente y descendente)

		// Ascendente
		for (int i=1; i<=10; i++) {
			System.out.println(i);
		}
		
		System.out.println("---------------------");
		
		// Descendente
		for(int i=10; i>=1; i--) {
			System.out.println(i);
		}
		
	}

}

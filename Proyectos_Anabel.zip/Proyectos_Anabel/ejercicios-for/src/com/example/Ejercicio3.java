package com.example;

public class Ejercicio3 {

	public static void main(String[] args) {
		// Escribir la tabla de multiplicar del 5
		
		for(int i=1; i<=10; i++) {
			System.out.println("5 x " + i + " = " + (5*i));
		}

	}

}

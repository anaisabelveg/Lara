package com.example;

public class Ejercicio6 {

	public static void main(String[] args) {
		// Hallar los números impares menores de 30 y que aparezcan en orden descendente

		for (int i = 30; i >= 0; i--) {
			if (i % 2 == 1) {
				System.out.println(i);
			}
		}

		for (int i = 29; i > 0; i -= 2) {
			System.out.println(i);
		}
	}

}

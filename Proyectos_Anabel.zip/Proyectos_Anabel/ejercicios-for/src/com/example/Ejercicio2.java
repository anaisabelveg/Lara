package com.example;

public class Ejercicio2 {

	public static void main(String[] args) {
		// Escribir "Feliz Navidad 1990" hasta 2007

		for(int anyo = 1990; anyo <=2007; anyo++) {
			System.out.println("Feliz Navidad " + anyo);
		}
	}

}

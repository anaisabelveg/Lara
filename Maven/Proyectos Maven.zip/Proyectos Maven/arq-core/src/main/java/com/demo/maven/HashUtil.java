package com.demo.maven;

import org.apache.commons.codec.digest.DigestUtils;

public class HashUtil {
	public static String hash(String... str) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < str.length; i++) {
			sb.append(str[i]);
		}
		return DigestUtils.shaHex(sb.toString());
	}
}

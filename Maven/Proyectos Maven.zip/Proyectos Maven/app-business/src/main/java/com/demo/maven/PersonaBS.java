package com.demo.maven;

public class PersonaBS {

	public String hashNombre(String nombre, String apellido) {
		if (nombre == null) {
			throw new RuntimeException("nombre no debe ser null");
		}
		if (apellido == null) {
			throw new RuntimeException("apellido no debe ser null");
		}
		return HashUtil.hash(nombre, apellido);
	}

}

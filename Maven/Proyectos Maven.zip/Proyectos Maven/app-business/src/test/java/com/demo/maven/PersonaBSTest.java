package com.demo.maven;

import org.apache.commons.codec.digest.DigestUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PersonaBSTest {

	private PersonaBS personaBS;

	@Before
	public void before() {
		personaBS = new PersonaBS();
	}

	@Test
	public void testHashNombre() {
		String nombre = "John";
		String apellido = "Doe";
		String expected = DigestUtils.shaHex(nombre + apellido);
		String result = personaBS.hashNombre(nombre, apellido);
		Assert.assertEquals(expected, result);
	}

}

package app.web;

import java.util.Date;
import java.util.GregorianCalendar;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import app.modelo.DNI;

@ManagedBean
@SessionScoped
public class UsuarioBean {
	
	private Date fecha;
	private Number numero;
	private DNI dni;
	
	public UsuarioBean() {
		fecha = new GregorianCalendar().getTime();
		numero = new Double(15.75);
	}
	
	public DNI getDni() {
		return dni;
	}
	
	public void setDni(DNI dni) {
		this.dni = dni;
	}
	
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Number getNumero() {
		return numero;
	}
	public void setNumero(Number numero) {
		this.numero = numero;
	}

}

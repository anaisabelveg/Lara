package app.web;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;

import app.modelo.DNI;

@FacesConverter(value="dniConverter")
public class DniConverter implements Converter{

	@Override
	public Object getAsObject(FacesContext contexto, 
			                  UIComponent componente, 
			                  String value) {
		// .... validamos que el value tiene formato de DNI
		return new DNI(value);
	}

	@Override
	public String getAsString(FacesContext contexto, 
			                  UIComponent componente, 
			                  Object objeto) {
		
		return ((DNI)objeto).getDni();
	}

}

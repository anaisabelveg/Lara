package app.web;

import javax.faces.bean.ManagedBean;
import javax.faces.event.ActionEvent;

@ManagedBean(name="eventos")
public class EventosBean {
	
	private String dato;
	private String mensaje;
	
	public void recogerEvento(ActionEvent event){
		// Recuperar el id del componente desde el que se lanza el evento
		String componente = event.getComponent().getId();
		
		// Elaboramos el mensaje a mostrar en la pagina
		mensaje = "Componente pulsado " + componente;
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public String getDato() {
		return dato;
	}
	
	public void setDato(String dato) {
		this.dato = dato;
	}

}

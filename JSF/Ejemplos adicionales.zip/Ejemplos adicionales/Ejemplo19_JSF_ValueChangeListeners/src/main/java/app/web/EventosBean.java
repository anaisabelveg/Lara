package app.web;

import javax.faces.bean.ManagedBean;
import javax.faces.event.ValueChangeEvent;

@ManagedBean(name="eventos")
public class EventosBean {
	
	private String mensaje;
	
	public void capturarEvento(ValueChangeEvent evento) {
		// Componente que lanza el evento
		String componente = evento.getComponent().getId();
		
		String seleccionado = evento.getNewValue().toString();
		
		mensaje = "El componente " + componente + 
				" ha cambiado su valor a " + seleccionado;
				
	}
	
	public String getMensaje() {
		return mensaje;
	}

}

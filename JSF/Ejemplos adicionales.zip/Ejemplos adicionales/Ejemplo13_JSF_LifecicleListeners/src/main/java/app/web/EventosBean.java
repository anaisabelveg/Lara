package app.web;

import javax.faces.bean.ManagedBean;
import javax.faces.lifecycle.Lifecycle;

@ManagedBean(name="eventos")
public class EventosBean {
	
	public void antesValidacion(){
		System.out.println("Se va a proceder a la validacion");
	}
	
	public void afterValidacion(){
		System.out.println("Se ha validado el componente");
	}

}

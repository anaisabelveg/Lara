package listeners;

import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;

public class MiListener implements ActionListener{

	@Override
	public void processAction(ActionEvent evento) 
			    throws AbortProcessingException {
		
		System.out.println("Evento detectado");
		
	}

}

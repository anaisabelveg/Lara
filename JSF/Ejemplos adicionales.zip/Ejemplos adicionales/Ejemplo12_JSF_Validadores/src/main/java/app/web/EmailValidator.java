package app.web;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator(value = "emailValidator")
public class EmailValidator implements Validator {

	@Override
	public void validate(FacesContext contexto, UIComponent componente,
			Object valor) throws ValidatorException {


			ResourceBundle rb = ResourceBundle.getBundle("errores", contexto.getViewRoot().getLocale());

			String email = (String) valor;

			if (email.indexOf("@") == -1) {
				throw new ValidatorException(new FacesMessage(
						                    rb.getString("error.email")));
			}

			// Otra forma de acceder al archivo de propiedades
//			FacesContext facesContext = FacesContext.getCurrentInstance();
//		    ResourceBundle bundle = 
//		        facesContext.getApplication().getResourceBundle(
//		            facesContext, "errores");
//		    String msg = bundle.getString("error.email");

	}

}

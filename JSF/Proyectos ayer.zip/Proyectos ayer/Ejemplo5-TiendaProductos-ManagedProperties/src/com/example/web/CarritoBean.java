package com.example.web;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;

import com.example.modelo.Producto;
import com.example.persistencia.ProductosDAO;

@ManagedBean(name = "carrito")
@SessionScoped
public class CarritoBean implements Serializable {

	private double importe;
	private List<Producto> contenido = new ArrayList<>();

	// Para que se pueda inyectar la propiedad
	// debemos tener los get y set de la propiedad dao
	@ManagedProperty(value = "#{miDao}") // name del bean ProductosDAO
	private ProductosDAO dao;

	public String addProducto(int id) {
		Producto encontrado = dao.buscar(id);
		contenido.add(encontrado);
		importe += encontrado.getPrecio();
		return "mostrarCarrito";
	}

	public String sacarDelCarrito(int id) {
		Producto encontrado = null;
		for (Producto producto : contenido) {
			if (id == producto.getId()) {
				encontrado = producto;
				break;
			}
		}
		contenido.remove(encontrado);
		importe -= encontrado.getPrecio();

		return "mostrarCarrito";
	}

	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

	public List<Producto> getContenido() {
		return contenido;
	}

	public void setContenido(List<Producto> contenido) {
		this.contenido = contenido;
	}
	
	public ProductosDAO getDao() {
		return dao;
	}
	
	public void setDao(ProductosDAO dao) {
		this.dao = dao;
	}

}

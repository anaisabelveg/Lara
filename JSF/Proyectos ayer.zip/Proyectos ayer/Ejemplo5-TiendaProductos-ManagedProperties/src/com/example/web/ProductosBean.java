package com.example.web;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import com.example.modelo.Producto;
import com.example.persistencia.ProductosDAO;

@ManagedBean
// Si no pongo nombre al managed bean
// toma el nombre de la clase primera letra en minuscula 
public class ProductosBean {
	
	// Para que se pueda inyectar la propiedad
	// debemos tener los get y set de la propiedad dao
	@ManagedProperty(value="#{miDao}") //name del bean ProductosDAO
	private ProductosDAO dao;
	
	private Producto producto = new Producto();
	
	public String eliminar() {
		dao.eliminar(producto.getId());
		return "index";
	}
	
	public String buscar() {
		producto = dao.buscar(producto.getId());
		return "mostrarProducto";
	}
	
	public List<Producto> consultarTodos(){
		return dao.todos();
	}
	
	public String altaProducto() {
		dao.altaProducto(producto);
		return "index";
	}

	public Producto getProducto() {
		return producto;
	}
	
	public void setProducto(Producto producto) {
		this.producto = producto;
	}
	
	public ProductosDAO getDao() {
		return dao;
	}
	
	public void setDao(ProductosDAO dao) {
		this.dao = dao;
	}
}

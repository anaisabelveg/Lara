package com.example.persistencia;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import com.example.modelo.Producto;

// eager=true significa que se genera la instancia de esta clase
// nada mas arrancar la aplicacion y no en la primera peticion
@ManagedBean(name="miDao", eager=true)
@ApplicationScoped // con esto conseguimos que solo haya una instancia
public class ProductosDAO implements Serializable {
	
	SessionFactory sf = null;
	Session session = null;
	
	public ProductosDAO() {
		// Crear SessionFactory
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		sf = new MetadataSources(registry).buildMetadata()
				.buildSessionFactory();
		session = sf.openSession();
	}
	
	
	@PostConstruct
	public void init() {
		// Se invoca nada mas crear la instancia del DAO
		System.out.println("El bean dao se acaba de crear");
	}
	
	@PreDestroy
	public void destroy() {
		// Se invoca justo antes de eliminar la instancia del DAO
		System.out.println("El bean dao se va a destruir");
	}
	
	public void eliminar(int id) {
		Session session = sf.openSession();
		Transaction tx = session.getTransaction();
		Producto encontrado = buscar(id);
		try {
			tx.begin();
			session.delete(encontrado);
			tx.commit();
		}catch(Exception ex) {
			tx.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	public List<Producto> todos(){
		Session session = sf.openSession();
		Query<Producto> query = session.createQuery("from Producto p");
		List<Producto> lista = query.list();
		session.close();
		return lista;
	}
	
	public Producto buscar(int id){
		Session session = sf.openSession();
		Producto encontrado = session.find(Producto.class, id);
		session.close();
		return encontrado;
	}
	
	public void altaProducto(Producto nuevo) {
		Session session = sf.openSession();
		Transaction tx = session.getTransaction();
		try {
			tx.begin();
			session.save(nuevo);
			tx.commit();
		}catch(Exception ex) {
			tx.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
		}
	}

}

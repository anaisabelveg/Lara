package com.example;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class LoginBean {
	
	private String usuario;
	private String pw;
	
	public String mostrar() {
		return "bienvenido";
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}
	
	
}

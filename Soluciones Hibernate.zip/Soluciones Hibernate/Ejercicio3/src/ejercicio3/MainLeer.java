package ejercicio3;

import app.modelo.Escuderia;
import app.modelo.Piloto;
import app.modelo.Telefono;
import app.modelo.Temporada;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MainLeer {

    public static void main(String[] args) {
        SessionFactory sf =
                new Configuration().configure().buildSessionFactory();
        Session session = sf.openSession();

        // 1.- Mostrar los pilotos que pertenecen a una determinada temporada
        Query q1 = session.createQuery("select t from Temporada t "
                + " where t.inicio = :inicio AND t.fin = :fin");
        q1.setParameter("inicio", 2010);
        q1.setParameter("fin", 2011);

        Temporada temporada = (Temporada) q1.uniqueResult();
        for (Piloto p : temporada.getPilotos()) {
            System.out.println(p);
        }
        System.out.println("=============================================");

        // 2.- Mostrar los pilotos de una escuderia
        Query q2 = session.createQuery("select e from Escuderia e where "
                + "e.nombre = :nom");
        q2.setParameter("nom", "Ferrari");
        Escuderia escuderia = (Escuderia) q2.uniqueResult();
        for (Piloto p : escuderia.getPilotos()) {
            System.out.println(p);
        }
        System.out.println("=============================================");

        // 3.- Mostrar los pilotos con un sueldo superior a una cifra
        Query q3 = session.createQuery("select p from Piloto p "
                + "where p.facturacion.sueldo > 4000000");
        List<Piloto> pilotos = q3.list();
        for (Piloto p : pilotos) {
            System.out.println(p);
        }
        System.out.println("=============================================");

        // 4.- Mostrar los pilotos que cobren por publicidad entre 2 valores
        Query q4 = session.createQuery("select p from Piloto p "
                + "where p.facturacion.publicidad "
                + "BETWEEN  :min AND :max");
        q4.setParameter("min", 1500000);
        q4.setParameter("max", 4000000);
        List<Piloto> masRicos = q4.list();
        for (Piloto p : masRicos) {
            System.out.println(p);
        }
        System.out.println("=============================================");


        // 5.- Mostrar los pilotos que no sean de la escuderia italiana
        Query q5 = session.createQuery("select p from Piloto p where "
                + "p.escuderia.pais NOT IN (:pais)");
        q5.setParameter("pais", "Italia");
        List<Piloto> noItalianos = q5.list();
        for (Piloto p : noItalianos) {
            System.out.println(p);
        }
        System.out.println("=============================================");


        // 6.- Mostrar todos los telefonos de Alonso
        Query q6 = session.createQuery("select t from Telefono t where "
                + "t.piloto.nombre = :nom ").setParameter("nom", "Alonso");
        List<Telefono> telAlonso = q6.list();
        for (Telefono tf : telAlonso) {
            System.out.println(tf);
        }
        System.out.println("=============================================");

    }
}

package ejercicio1;

import app.modelo.Persona;
import java.util.List;
import org.hibernate.Query;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MainLeer {

    public static void main(String[] args) {


        SessionFactory sf =
                new Configuration().configure().buildSessionFactory();
        Session session = sf.openSession();

        try {
            Query consulta = session.createQuery("from Persona p order by p.codigo desc");
            List<Persona> personas = consulta.list();

            System.out.println(personas.size() + " persona(s) encontradas.");


            for (Persona p : personas) {
                System.out.println(p);
            }
        } catch (Exception ex) {

            ex.printStackTrace();
        } finally {
            session.close();
            sf.close();
        }
    }
}

package ejercicio1;

import app.modelo.Persona;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SessionFactory sf =
                new Configuration().configure().buildSessionFactory();

        Session session = sf.openSession();

        Transaction tx = session.getTransaction();

        try {
            tx.begin();
            System.out.println("Almacenando 20 personas");

            for (int i = 1; i <= 20; i++) {
                session.save(new Persona("Persona " + i, "dni " + i));
            }

            tx.commit();
        } catch (Exception ex) {
            tx.rollback();
            ex.printStackTrace();
        } finally {
            session.close();
            sf.close();
        }
    }
}


        
package hibernatesingletable;

import app.modelo.Camion;
import app.modelo.Coche;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    public static void main(String[] args) {
        SessionFactory sf =
                new Configuration().configure().buildSessionFactory();
        Session sesion = sf.openSession();
        Transaction tx = sesion.getTransaction();

        // Crear objetos => NEW
        Coche co1 = new Coche("FORD MONDEO", 205F, 130, 4, 4.20F);
        Coche co2 = new Coche("SEAT LEON", 220.0F, 150, 5, 4.0F);
        Coche co3 = new Coche("MERCEDES CLK", 247F, 280, 3, 4.0F);
        Camion ca1 = new Camion("IBECO 300", 150F, 300, 3000, 14000);
        Camion ca2 = new Camion("RENAULT F2000", 140F, 250, 4000, 9000);


        try{
            tx.begin();
            sesion.save(co1);
            sesion.save(co2);
            sesion.save(co3);
            sesion.save(ca1);
            sesion.save(ca2);
            tx.commit();

        }catch(Exception ex){
            tx.rollback();
            ex.printStackTrace();
        }finally{
            sesion.close();
            sf.close();
        }
    }

}

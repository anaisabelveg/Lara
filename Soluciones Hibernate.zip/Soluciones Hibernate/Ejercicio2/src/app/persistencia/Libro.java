package app.persistencia;

import java.io.Serializable;

public class Libro implements Serializable {

 
    private LibroPK libroPk;
    private String descripcion;
    private String resumen;

    /* Es obligatorio */
    public Libro() {
    }

    public Libro(LibroPK libroPk, String descripcion, String resumen) {
        this.libroPk = libroPk;
        this.descripcion = descripcion;
        this.resumen = resumen;
    }

    public void setLibroPk(LibroPK libroPk) {
        this.libroPk = libroPk;
    }

    public LibroPK getLibroPk() {
        return libroPk;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getResumen() {
        return resumen;
    }

    public void setResumen(String resumen) {
        this.resumen = resumen;
    }



    @Override
    public String toString() {
        return "Libro [libroPk= " + libroPk + ", descripcion=" + descripcion
                + ", resumen=" + resumen + "]";
    }
}

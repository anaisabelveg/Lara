package app.persistencia;

import java.io.Serializable;

public class LibroPK implements Serializable {

    private String titulo;
    private String autor;

    public LibroPK() {
    }

    public LibroPK(String titulo, String autor) {
        super();
        this.titulo = titulo;
        this.autor = autor;
    }
    
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((autor == null) ? 0 : autor.hashCode());
        result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        LibroPK other = (LibroPK) obj;
        if (autor == null) {
            if (other.autor != null) {
                return false;
            }
        } else if (!autor.equals(other.autor)) {
            return false;
        }
        if (titulo == null) {
            if (other.titulo != null) {
                return false;
            }
        } else if (!titulo.equals(other.titulo)) {
            return false;
        }
        return true;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return "LibroPK [titulo=" + titulo + ", autor=" + autor + "]";
    }
}

package ejercicio2;

import app.persistencia.Libro;
import app.persistencia.LibroPK;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SessionFactory sf =
        new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();

        Session session = sf.openSession();

        Transaction tx = session.getTransaction();

        try {
            tx.begin();
            // Almacenar 5 libros
            System.out.println("Almacenando libros ------------------------------");

            session.save(new Libro(new LibroPK("Los pilares de la tierra", "Ken Follet"), "Descripcion 1", "Resumen 1"));
            session.save(new Libro(new LibroPK("La caida de los gigantes", "Ken Follet"), "Descripcion 2", "Resumen 2"));
            session.save(new Libro(new LibroPK("El tiempo entre costuras", "Maria Due����as"), "Descripcion 3", "Resumen 3"));
            session.save(new Libro(new LibroPK("Mision olvido", "Maria Due����as"), "Descripcion 4", "Resumen 4"));
            session.save(new Libro(new LibroPK("Como agua para chocolate", "Isabel Allende"), "Descripcion 5", "Resumen 5"));

            tx.commit();

           
        } catch (Exception ex) {
            tx.rollback();
            ex.printStackTrace();
        } finally {
            session.close();
            sf.close();
        }
    }
}

package ejercicio2;

import app.persistencia.Libro;
import java.util.List;
import org.hibernate.Query;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainLeer {

    public static void main(String[] args) {


        SessionFactory sf =
                new Configuration().configure("hibernate_leer.cfg.xml").buildSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.getTransaction();

        try {
            System.out.println("Consultando todos los libros --------------------");

            List<Libro> libros = session.createQuery("from Libro p order by p.libroPk.titulo asc").list();
            for (Libro p : libros) {
                System.out.println(p);
            }

            System.out.println("Consultando los libros de Ken Follet --------------------");
            Query q1 = session.createQuery("from Libro p where p.libroPk.autor = :autor");
            q1.setParameter("autor", "Ken Follet");
            List<Libro> librosKen = q1.list();
            for (Libro p : librosKen) {
                System.out.println(p);
            }

            System.out.println("Eliminar el libro 'El tiempo entre costuras' --------------------");
            Query q2 = session.createQuery("delete from Libro p where p.libroPk.titulo = :title");
            q2.setParameter("title", "El tiempo entre costuras");
            tx.begin();
            q2.executeUpdate();
            tx.commit();

            System.out.println("Modificar la descripcion del libro 'Los Pilares de la tierra' --------------------");
            Query q3 = session.createQuery("update Libro p SET p.descripcion = :desc WHERE p.libroPk.titulo = :title");
            q3.setParameter("desc", "Nueva descripcion");
            q3.setParameter("title", "Los pilares de la tierra");
            tx.begin();
            q3.executeUpdate();
            tx.commit();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            session.close();
            sf.close();
        }
    }
}

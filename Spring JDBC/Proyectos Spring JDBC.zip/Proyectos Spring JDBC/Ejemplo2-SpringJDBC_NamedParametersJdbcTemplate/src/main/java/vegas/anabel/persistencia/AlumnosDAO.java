package vegas.anabel.persistencia;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import vegas.anabel.modelos.Alumno;

public class AlumnosDAO {
	
	private NamedParameterJdbcTemplate template;
	private RowMapper<Alumno> mapeadorAlumno;
	
	public void modificarNota(int id, double nuevaNota) {
		String sql = "update Alumnos set NOTA= :nota where idAlumnos= :codigo";
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("codigo", id);
		parametros.put("nota", nuevaNota);
		template.update(sql, parametros);
	}
	
	public void eliminar(int id) {
		String sql = "delete from Alumnos where idAlumnos= :codigo";
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("codigo", id);
		template.update(sql, parametros);
	}
	
	public void alta(Alumno nuevo) {
		String sql = "insert into Alumnos values (:id,:nombre,:apellido,"
				+ ":fecha,:repe,:nota)";
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("id", nuevo.getID());
		parametros.put("nombre", nuevo.getNombre());
		parametros.put("apellido", nuevo.getApellido());
		parametros.put("fecha", new java.sql.Date(nuevo.getFechaNacimiento().getTime()));
		parametros.put("repe", nuevo.isRepetidor());
		parametros.put("nota", nuevo.getNota());
		template.update(sql, parametros);
	}
	
	public Alumno buscarAlumno(int id) {
		String sql = "select * from Alumnos where idAlumnos = :codigo";
		Map<String, Object> parametros = new HashMap<>();
		parametros.put("codigo", id);
		return template.queryForObject(sql, parametros, mapeadorAlumno);
	}
	
	public List<Alumno> consultarTodos(){		
		return template.query("select * from Alumnos", mapeadorAlumno);
	}

	public NamedParameterJdbcTemplate getTemplate() {
		return template;
	}
	
	public void setTemplate(NamedParameterJdbcTemplate template) {
		this.template = template;
	}

	public RowMapper<Alumno> getMapeadorAlumno() {
		return mapeadorAlumno;
	}

	public void setMapeadorAlumno(RowMapper<Alumno> mapeadorAlumno) {
		this.mapeadorAlumno = mapeadorAlumno;
	}
	
}

package vegas.anabel.persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import vegas.anabel.modelos.Alumno;

public class AlumnosDAO {
	
	private Connection conexion;
	
	public void modificarNota(int id, double nuevaNota) {
		try {
			abrirConexion();
			String sql = "update Alumnos set NOTA=? where idAlumnos=?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setDouble(1, nuevaNota);
			pst.setInt(2, id);
			int filas = pst.executeUpdate();
			System.out.println(filas + " Modificadas");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	public void eliminar(int id) {
		try {
			abrirConexion();
			String sql = "delete from Alumnos where idAlumnos=?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, id);
			int filas = pst.executeUpdate();
			System.out.println(filas + " Eliminadas");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	public void alta(Alumno nuevo) {
		try {
			abrirConexion();
			String sql = "insert into Alumnos values (?,?,?,?,?,?)";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, nuevo.getID());
			pst.setString(2, nuevo.getNombre());
			pst.setString(3, nuevo.getApellido());
			
			pst.setDate(4, 
				new java.sql.Date(nuevo.getFechaNacimiento().getTime()));
			
			pst.setBoolean(5, nuevo.isRepetidor());
			pst.setDouble(6, nuevo.getNota());
			
			int filas = pst.executeUpdate();
			System.out.println(filas + " Insertadas");
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
	}
	
	public Alumno buscarAlumno(int id) {
		Alumno encontrado = new Alumno();
		
		try {
			abrirConexion();
			String sql = "select * from Alumnos where idAlumnos = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			
			// Resolver el parametro
			pst.setInt(1, id);
			
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				encontrado.setID(rs.getInt("idAlumnos"));
				encontrado.setNombre(rs.getString("NOMBRE"));
				encontrado.setApellido(rs.getString("APELLIDO"));
				encontrado.setFechaNacimiento(rs.getDate("FECHA_NACIMIENTO"));
				encontrado.setRepetidor(rs.getBoolean("REPETIDOR"));
				encontrado.setNota(rs.getDouble("NOTA"));
			}
					
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			cerrarConexion();
		}
		
		return encontrado;
	}
	
	public List<Alumno> consultarTodos(){
		List<Alumno> lista = new ArrayList<>();
		
		try {
			abrirConexion();
			
			// 3.- Preparar la query
			Statement stm = conexion.createStatement();
			
			// 4.- Ejecutar la query
			ResultSet rs = stm.executeQuery("select * from Alumnos");
			
			// 5.- Procesar el resultado
			while(rs.next()) {
				Alumno alumno = new Alumno();
				alumno.setID(rs.getInt("idAlumnos"));
				alumno.setNombre(rs.getString("NOMBRE"));
				alumno.setApellido(rs.getString("APELLIDO"));
				alumno.setFechaNacimiento(rs.getDate("FECHA_NACIMIENTO"));
				alumno.setRepetidor(rs.getBoolean("REPETIDOR"));
				alumno.setNota(rs.getDouble("NOTA"));
				
				lista.add(alumno);
			}
			
		} catch(SQLException ex) {
			ex.printStackTrace();
		}finally {
			// Siempre se ejecuta haya excepcion o no
			cerrarConexion();
		}
		
		
		
		return lista;
	}
	
	private void abrirConexion() {
		try {
			// 1.- Cargar el driver de mysql
			Class.forName("com.mysql.jdbc.Driver");
			
			// 2.- Abrir una conexion a la BBDD
		    conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/LaraDB",
					"root", "");
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
			ex.printStackTrace();
		}
	}
	
	private void cerrarConexion() {
		try {
			// 6.- Cerrar la conexion
			conexion.close();
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}

}

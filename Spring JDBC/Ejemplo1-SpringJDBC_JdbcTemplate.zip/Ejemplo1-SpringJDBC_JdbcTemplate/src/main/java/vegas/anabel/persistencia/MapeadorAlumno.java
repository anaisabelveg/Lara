package vegas.anabel.persistencia;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import vegas.anabel.modelos.Alumno;

public class MapeadorAlumno implements RowMapper<Alumno>{

	@Override
	public Alumno mapRow(ResultSet rs, int i) throws SQLException {
		Alumno alumno = new Alumno();
		alumno.setID(rs.getInt("idAlumnos"));
		alumno.setNombre(rs.getString("NOMBRE"));
		alumno.setApellido(rs.getString("APELLIDO"));
		alumno.setFechaNacimiento(rs.getDate("FECHA_NACIMIENTO"));
		alumno.setRepetidor(rs.getBoolean("REPETIDOR"));
		alumno.setNota(rs.getDouble("NOTA"));
		return alumno;
	}

}

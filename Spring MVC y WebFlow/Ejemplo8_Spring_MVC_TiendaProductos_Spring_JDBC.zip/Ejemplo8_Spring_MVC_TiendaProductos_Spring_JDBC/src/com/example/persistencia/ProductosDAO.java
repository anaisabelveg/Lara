package com.example.persistencia;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.modelo.Producto;

@Repository
public class ProductosDAO {
	
	@Autowired
	private JdbcTemplate template;
	
	@Autowired
	private MapeadorProducto mapeador;
	
	@Transactional
	public void alta(Producto nuevo) {
		String sql = "insert into Productos values (?,?,?)";
		template.update(sql, 
			nuevo.getId(), nuevo.getDescripcion(), nuevo.getPrecio());
	}
	
	public Producto buscar(int id){
		String sql = "select * from Productos where ID = ?";
		return template.queryForObject(sql, new Object[] { id }, mapeador);
	}
	
	public List<Producto> todos(){
		return template.query("select * from Productos", mapeador);
	}
	
	public MapeadorProducto getMapeador() {
		return mapeador;
	}
	
	public void setMapeador(MapeadorProducto mapeador) {
		this.mapeador = mapeador;
	}
	
	public JdbcTemplate getTemplate() {
		return template;
	}
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

}

package com.example.persistencia;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.example.modelo.Producto;

@Repository
public class ProductosDAO {
	
	public List<Producto> todos(){
		List<Producto> lista = new ArrayList<>();
		for(int i=1; i<=10; i++) {
			lista.add(new Producto(i, "Producto " + i, i*10));
		}
		return lista;
	}

}

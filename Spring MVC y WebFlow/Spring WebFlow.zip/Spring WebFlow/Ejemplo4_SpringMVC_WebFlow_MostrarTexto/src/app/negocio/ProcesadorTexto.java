package app.negocio;

import org.springframework.stereotype.Component;

@Component(value="procesador")
public class ProcesadorTexto {
	
	public String convertirMayusculas(String texto){
		return texto.toUpperCase();
	}

}

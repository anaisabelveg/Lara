package com.example.negocio;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.example.modelo.Producto;

@Component(value = "miCarro")
@Scope("session")
public class Carrito implements Serializable {

	private double importe;
	private List<Producto> contenido = new ArrayList<>();

	public void agregarProducto(Producto producto) {
		contenido.add(producto);
		importe += producto.getPrecio();
	}
	
	public void sacarProducto(Producto producto) {
		Producto eliminar = null;
		for (Producto p : contenido) {
			if (p.getId() == producto.getId()) {
				eliminar = p;
				break;
			}
		}
		contenido.remove(eliminar);
		importe -= eliminar.getPrecio();
	}
	
	public double getImporte() {
		return importe;
	}

	public void setImporte(double importe) {
		this.importe = importe;
	}

	public List<Producto> getContenido() {
		return contenido;
	}

	public void setContenido(List<Producto> contenido) {
		this.contenido = contenido;
	}

}

package com.example.persistencia;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.modelo.Producto;

@Repository
public class ProductosDAO {
	
	@Autowired
	private EntityManagerFactory emf;
	
	public void alta(Producto nuevo) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		try {
			et.begin();
			em.persist(nuevo);
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}
	}
	
	public Producto buscar(int id){
		EntityManager em = emf.createEntityManager();
		Producto encontrado = em.find(Producto.class, id);
		em.close();
		return encontrado;
	}
	
	public List<Producto> todos(){
		EntityManager em = emf.createEntityManager();
		Query query = em.createQuery("select p from Producto p");
		List<Producto> lista = query.getResultList();
		em.close();
		return lista;
	}

	public EntityManagerFactory getEmf() {
		return emf;
	}

	public void setEmf(EntityManagerFactory emf) {
		this.emf = emf;
	}
	
	

}

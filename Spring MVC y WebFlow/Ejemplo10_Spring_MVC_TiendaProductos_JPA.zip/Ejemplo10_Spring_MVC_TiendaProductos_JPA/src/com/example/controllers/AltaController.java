package com.example.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.modelo.Producto;
import com.example.persistencia.ProductosDAO;

@Controller
@RequestMapping("/alta")
public class AltaController {

	@Autowired
	private ProductosDAO dao;

	@RequestMapping(method = RequestMethod.GET)
	public String enviarFormulario(Model model) {
		model.addAttribute("producto", new Producto());
		return "formularioAlta";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String procesarFormulario(@Valid Producto producto,
			BindingResult resultado, Model model) {

		if (resultado.hasErrors()) {
			return "formularioAlta";
		} else {
			dao.alta(producto);
			model.addAttribute("mensaje", "Producto insertado en la BBDD");
			return "mostrarMensaje";
		}

	}

	public ProductosDAO getDao() {
		return dao;
	}

	public void setDao(ProductosDAO dao) {
		this.dao = dao;
	}

}

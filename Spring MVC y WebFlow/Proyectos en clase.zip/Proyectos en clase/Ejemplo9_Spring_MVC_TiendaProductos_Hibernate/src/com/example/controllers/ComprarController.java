package com.example.controllers;

import java.io.Serializable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.modelo.Producto;
import com.example.negocio.Carrito;
import com.example.persistencia.ProductoDO;
import com.example.persistencia.ProductosDAO;

@Controller
@Scope("session")
public class ComprarController implements Serializable{
	
	@Autowired
	private ProductosDAO dao;
	
	@Autowired
	private Carrito miCarro;
	
	@GetMapping(value="/comprar")
	public String addProducto(@RequestParam("codigo") int id) {
		//int id = request.getParameter("codigo");
		Producto encontrado = dao.buscar(id);
		miCarro.agregarProducto(encontrado);
		return "mostrarCarrito";
	}
	
	@GetMapping(value="/eliminar")
	public String eliminarProducto(@RequestParam("codigo") int id) {
		//int id = request.getParameter("codigo");
		Producto encontrado = dao.buscar(id);
		miCarro.sacarProducto(encontrado);
		return "mostrarCarrito";
	}

}















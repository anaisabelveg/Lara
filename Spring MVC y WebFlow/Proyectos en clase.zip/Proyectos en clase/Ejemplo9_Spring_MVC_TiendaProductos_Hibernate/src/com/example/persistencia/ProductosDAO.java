package com.example.persistencia;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.modelo.Producto;

@Repository
public class ProductosDAO {
	
	@Autowired
	private SessionFactory sf;
	
	public void alta(Producto nuevo) {
		ProductoDO entidad = productoToProductoDO(nuevo);
		Session session = sf.openSession();
		Transaction tx = session.getTransaction();
		try {
			tx.begin();
			session.save(entidad);
			tx.commit();
		}catch(Exception ex) {
			tx.rollback();
			ex.printStackTrace();
		} finally {
			session.close();
		}
	}
	
	public Producto buscar(int id){
		System.out.println(id + "---------------");
		Session session = sf.openSession();
		ProductoDO encontrado = session.find(ProductoDO.class, id);
		session.close();
		return productoDOToProducto(encontrado);
	}
	
	public List<Producto> todos(){
		Session session = sf.openSession();
		Query<ProductoDO> query = session.createQuery("from ProductoDO p");
		List<ProductoDO> lista = query.list();
		
		List<Producto> otra = new ArrayList<Producto>();
		for (ProductoDO producto : lista) {
			otra.add(productoDOToProducto(producto));
		}
		session.close();
		return otra;
	}
	
	private Producto productoDOToProducto(ProductoDO producto) {
		Producto p = new Producto(producto.getId(), 
				producto.getDescripcion(), producto.getPrecio());
		return p;
	}
	
	private ProductoDO productoToProductoDO(Producto producto) {
		ProductoDO p = new ProductoDO(producto.getId(), 
				producto.getDescripcion(), producto.getPrecio());
		return p;
	}
	
	public SessionFactory getSf() {
		return sf;
	}
	
	public void setSf(SessionFactory sf) {
		this.sf = sf;
	}

}

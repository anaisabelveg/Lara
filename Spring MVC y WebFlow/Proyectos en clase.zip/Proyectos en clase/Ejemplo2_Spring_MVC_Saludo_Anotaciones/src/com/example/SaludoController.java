package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/saludar")
public class SaludoController{

	@RequestMapping(method = RequestMethod.GET)
	public String saludar(Model model){		
		model.addAttribute("mensaje", "Bienvenido a mi primera web con Spring");		
		return "mostrarSaludo";
	}

	
}

package com.example.negocio;

import javax.annotation.security.RolesAllowed;

import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Service;

@Service
public class MetodosSeguros {
	/*
	@Secured({"ROLE_USER"})
	public void metodo1() throws Exception{
		System.out.println("Ejecutando metodo1 para los usuarios con ROLE_USER");
	}
	
	@Secured({"ROLE_USER", "ROLE_ADMIN"})
	public void metodo2() throws Exception{
		System.out.println("Ejecutando metodo2 para los usuarios "
				+ "con ROLE_USER y ROLE_ADMIN");
	}
	*/
	@RolesAllowed({"ROLE_USER"})
	public void metodo1() throws Exception{
		System.out.println("Ejecutando metodo1 para los usuarios con ROLE_USER");
	}
	
	@RolesAllowed({"ROLE_USER", "ROLE_ADMIN"})
	public void metodo2() throws Exception{
		System.out.println("Ejecutando metodo2 para los usuarios "
				+ "con ROLE_USER y ROLE_ADMIN");
	}
	
}











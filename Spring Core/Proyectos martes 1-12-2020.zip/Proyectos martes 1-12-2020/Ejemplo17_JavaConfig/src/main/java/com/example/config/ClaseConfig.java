package com.example.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.modelo.Coche;
import com.example.negocio.Aseguradora;
import com.example.negocio.ITaller;
import com.example.negocio.TallerMecanica;
import com.example.negocio.TallerPintura;

@Configuration
public class ClaseConfig {

	@Bean
	public Coche coche() {
		return new Coche("A5", "1234-LDB");
	}
	
	@Bean
	public ITaller tallerMecanica() {
		return new TallerMecanica();
	}
	
	@Bean
	public ITaller tallerPintura() {
		return new TallerPintura();
	}
	
	@Bean
	public Aseguradora aseguradora() {
		Aseguradora aseguradora = new Aseguradora();
		aseguradora.setNombre("Mapfre");
		aseguradora.setTaller(tallerMecanica());
		return aseguradora;
	}
}









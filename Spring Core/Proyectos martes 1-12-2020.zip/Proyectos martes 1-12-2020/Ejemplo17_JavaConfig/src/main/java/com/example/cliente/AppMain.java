package com.example.cliente;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.config.ClaseConfig;
import com.example.modelo.Coche;
import com.example.negocio.Aseguradora;

public class AppMain {

	public static void main(String[] args) {
		// Crear un contenedor con todos los bean declarados
		// en applicationContext.xml
		// Levantar el contexto de Spring
		ApplicationContext contenedor = 
				new AnnotationConfigApplicationContext(ClaseConfig.class);
		
		// Recuperar el bean con id="coche"
		Coche coche = contenedor.getBean("coche", Coche.class);
		
		// Recuperar el bean con id="aseguradora"
		Aseguradora aseguradora = (Aseguradora) 
				contenedor.getBean("aseguradora");
		
		// Ejecutar la app
		aseguradora.arreglarCoche(coche);

	}

}

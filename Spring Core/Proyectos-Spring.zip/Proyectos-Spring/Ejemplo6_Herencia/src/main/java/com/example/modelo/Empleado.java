package com.example.modelo;

public class Empleado {

	private int numeroEmpleado;
	private String nombre;
	private String apellido;
	private boolean esJefe;
	private double sueldo;
	private String skill;
	private String proyecto;

	// Toda clase de la que queramos crear un bean
	// necesita un constructor por defecto
	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public String getProyecto() {
		return proyecto;
	}

	public void setProyecto(String proyecto) {
		this.proyecto = proyecto;
	}

	public int getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(int numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public boolean isEsJefe() {
		return esJefe;
	}

	public void setEsJefe(boolean esJefe) {
		this.esJefe = esJefe;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Empleado [numeroEmpleado=" + numeroEmpleado + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", esJefe=" + esJefe + ", sueldo=" + sueldo + ", skill=" + skill + ", proyecto=" + proyecto + "]";
	}

}

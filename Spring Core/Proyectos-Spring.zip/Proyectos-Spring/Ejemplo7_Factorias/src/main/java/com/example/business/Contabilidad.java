package com.example.business;

// Queremos que sea una clase de tipo Singleton
public class Contabilidad {
	
	// Mantenemos almacenada la UNICA INSTANCIA de la clase
	private static Contabilidad unicaInstancia = new Contabilidad();
	
	// Quitar visibilidad al constructor para que no se
	// pueda generar instancias
	private Contabilidad() {
		// TODO Auto-generated constructor stub
	}
	
	public static Contabilidad getInstance() {
		return unicaInstancia;
	}
	
	// Metodos de negocio
	public void pagoFacturas(String factura) {
		System.out.println("Pagando factura " + factura);
	}
	
	public void recibirCobro(String cobro) {
		System.out.println("Recibido cobro " + cobro);
	}

}










package com.example.cliente;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.business.Contabilidad;

public class AppMain {

	public static void main(String[] args) {
		// Crear un contenedor con todos los bean declarados
		// en applicationContext.xml
		// Levantar el contexto de Spring
		ApplicationContext contenedor = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Contabilidad contabilidad = 
				contenedor.getBean("contabilidad", Contabilidad.class);
		contabilidad.pagoFacturas("Factura numero: 27, "
				+ "importe 35000, concepto: compra coche");
		contabilidad.recibirCobro("1000€, concepto: Alquiler local");
	}

}










package com.example.modelo;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Empresa {

	private List<Empleado> empleados;
	private Set<String> proyectos;
	private Empleado[] equipos;
	private Map<String, Empleado> jefesProyecto;
	private Properties emails;

	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}

	public Set<String> getProyectos() {
		return proyectos;
	}

	public void setProyectos(Set<String> proyectos) {
		this.proyectos = proyectos;
	}

	public Empleado[] getEquipos() {
		return equipos;
	}

	public void setEquipos(Empleado[] equipos) {
		this.equipos = equipos;
	}

	public Map<String, Empleado> getJefesProyecto() {
		return jefesProyecto;
	}

	public void setJefesProyecto(Map<String, Empleado> jefesProyecto) {
		this.jefesProyecto = jefesProyecto;
	}

	public Properties getEmails() {
		return emails;
	}

	public void setEmails(Properties emails) {
		this.emails = emails;
	}

	@Override
	public String toString() {
		return "Empresa [empleados=" + empleados + 
				"\n proyectos=" + proyectos + 
				"\n equipos=" + Arrays.toString(equipos) +
				"\n jefesProyecto=" + jefesProyecto + 
				"\n emails=" + emails + "]";
	}
	
	

}











package com.example.negocio;

import com.example.modelo.Coche;

public class Aseguradora {

	private String nombre;
	private ITaller taller;
	
	public void arreglarCoche(Coche coche) {
		taller.reparar(coche);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ITaller getTaller() {
		return taller;
	}

	public void setTaller(ITaller taller) {
		this.taller = taller;
	}

}

package com.example.negocio;

import com.example.modelo.Coche;

public class TallerMecanica implements ITaller{

	public void reparar(Coche coche) {
		System.out.println("En el taller de mecanica se repara el coche "+coche);		
	}

}

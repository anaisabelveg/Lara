package com.example.cliente;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.modelo.Empleado;

public class AppMain {

	public static void main(String[] args) {
		// La clase abstract me permitira eliminar los beans
		AbstractApplicationContext contenedor = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Un bean de tipo Singleton significa que siempre es el mismo bean
		// lo podemos pedir tantas veces como queramos pero siempñre trabajamos 
		// sobre la misma instancia.
		Empleado empleado1 = (Empleado)contenedor.getBean("empleado1");
		Empleado empleado1Bis = (Empleado)contenedor.getBean("empleado1");
		System.out.println("Es el mismo bean los singleton? " + 
				(empleado1==empleado1Bis));
		
		// Un bean de tipo Prototype, el bean se guarda como una plantilla(prototipo)
		// cada vez que se solicita nos devuelve una instancia nueva.
		Empleado empleado2 = (Empleado)contenedor.getBean("empleado2");
		Empleado empleado2Bis = (Empleado)contenedor.getBean("empleado2");
		System.out.println("Es el mismo bean los prototypes? " + 
				(empleado2==empleado2Bis));
		
		// Eliminar todos los beans del contenedor
		contenedor.registerShutdownHook();
	}

}

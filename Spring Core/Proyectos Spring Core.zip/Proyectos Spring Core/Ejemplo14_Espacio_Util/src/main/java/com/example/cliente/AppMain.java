package com.example.cliente;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		// Crear un contenedor con todos los bean declarados
		// en applicationContext.xml
		// Levantar el contexto de Spring
		ApplicationContext contenedor = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		System.out.println(contenedor.getBean("empresa"));
	}

}

package com.example.modelo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

// Si no le pongo nombre al bean toma el nombre de la clase
// con la primera letra en minuscula
@Component("coche")
@Scope(value="prototype")
public class Coche {
	
	// DI por propiedades
	@Value("A5")
	private String modelo;
	
	@Value("1234-LDB")
	private String matricula;
	
	public Coche() {
		// TODO Auto-generated constructor stub
	}

	// DI a traves del constructor
	public Coche(@Value("A5")String modelo, @Value("1234-LDB")String matricula) {
		super();
		this.modelo = modelo;
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	@Override
	public String toString() {
		return "Coche [modelo=" + modelo + ", matricula=" + matricula + "]";
	}
	
	

}

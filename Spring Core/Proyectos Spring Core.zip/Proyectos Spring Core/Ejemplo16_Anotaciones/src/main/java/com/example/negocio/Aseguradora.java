package com.example.negocio;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.modelo.Coche;

@Service
public class Aseguradora {

	@Value("Mapfre")
	private String nombre;
	
	// La anotacion autowired no me permite poner el id del bean a inyectar
	// por eso necesito @Qualifier
	//@Autowired
	//@Qualifier("tallerMecanica")
	
	// Otra alternativa es utilizar la anotacion Resource
	@Resource(name="tallerPintura")
	private ITaller taller;
	
	public void arreglarCoche(Coche coche) {
		taller.reparar(coche);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ITaller getTaller() {
		return taller;
	}

	// Fuerza que el bean sea inyectado
	@Required
	public void setTaller(ITaller taller) {
		this.taller = taller;
	}

}

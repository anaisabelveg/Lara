package com.example.negocio;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.example.modelo.Coche;

@Service
@Lazy(value=true)
public class TallerPintura implements ITaller{

	public void reparar(Coche coche) {
		System.out.println("En el taller de pintura "
				+ "se pinta el coche "+coche);		
	}

}

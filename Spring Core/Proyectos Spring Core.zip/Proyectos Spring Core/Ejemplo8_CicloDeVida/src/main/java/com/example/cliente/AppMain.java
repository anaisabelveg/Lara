package com.example.cliente;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		// La clase abstract me permitira eliminar los beans
		AbstractApplicationContext contenedor = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		System.out.println(contenedor.getBean("empleado1"));
		System.out.println(contenedor.getBean("empleado2"));
		
		// Eliminar todos los beans del contenedor
		contenedor.registerShutdownHook();
	}

}

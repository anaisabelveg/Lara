package com.example.persistencia;

import java.util.List;

import com.example.modelo.Producto;

public class ProductosDAO {
	
	private DatosConexion datos;
	
	public List<Producto> productos(){
		// Trabajo para mañana al empezar la clase
		return null;
	}

	public DatosConexion getDatos() {
		return datos;
	}

	public void setDatos(DatosConexion datos) {
		this.datos = datos;
	}
	
	

}

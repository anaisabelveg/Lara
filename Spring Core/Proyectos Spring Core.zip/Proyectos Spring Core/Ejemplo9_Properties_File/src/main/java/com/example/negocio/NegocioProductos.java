package com.example.negocio;

import java.util.List;

import com.example.modelo.Producto;
import com.example.persistencia.ProductosDAO;

public class NegocioProductos {

	private ProductosDAO dao;
	
	public List<Producto> todos(){
		return dao.productos();
	}
	
	public ProductosDAO getDao() {
		return dao;
	}
	
	public void setDao(ProductosDAO dao) {
		this.dao = dao;
	}
}

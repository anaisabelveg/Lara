package com.example.negocio;

import com.example.modelo.Coche;

public interface ITaller {

	void reparar (Coche coche);
}

package com.example.modelo;

public class Coche {
	
	private String modelo;
	private String matricula;
	
	public Coche() {
		// TODO Auto-generated constructor stub
	}

	public Coche(String modelo, String matricula) {
		super();
		this.modelo = modelo;
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	@Override
	public String toString() {
		return "Coche [modelo=" + modelo + ", matricula=" + matricula + "]";
	}
	
	

}

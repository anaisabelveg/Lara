package com.example;

public interface Saludo {
	
	public String saludar(String nombre);

}

package com.example;

import java.util.List;

public interface GestionReparaciones {

	public List<String> todasReparaciones(String matricula);
}

package com.example;

public interface GestionCoches {
	
	public String buscarMatricula(String dni);

}

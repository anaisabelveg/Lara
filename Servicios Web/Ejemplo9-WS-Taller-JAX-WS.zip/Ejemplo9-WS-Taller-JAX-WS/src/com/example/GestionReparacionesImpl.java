package com.example;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public class GestionReparacionesImpl implements GestionReparaciones {

	@Override
	@WebMethod
	public List<String> todasReparaciones(@WebParam String matricula) {
		List<String> lista = new ArrayList<>();
		
		for(int i=1; i<=10; i++) {
			lista.add("Reparacion: " + i + ", Matricula: " + matricula +
					" Detalle de la reparacion");
		}
		
		return lista;
	}

}

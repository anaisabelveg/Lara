package com.example;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

@WebService
public class GestionCochesImpl implements GestionCoches {

	@Override
	@WebMethod
	public String buscarMatricula(@WebParam String dni) {
		// TODO Auto-generated method stub
		return "1234-LDK";
	}

}

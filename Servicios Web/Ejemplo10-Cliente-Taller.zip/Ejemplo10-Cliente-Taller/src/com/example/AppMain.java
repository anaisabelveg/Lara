package com.example;

import java.rmi.RemoteException;

public class AppMain {

	public static void main(String[] args) throws RemoteException {
		GestionCochesImpl swCoches =
				new GestionCochesImplProxy().getGestionCochesImpl();
		
		String matricula = swCoches.buscarMatricula("98123567-A");
		
		GestionReparacionesImpl swReparaciones =
				new GestionReparacionesImplProxy().getGestionReparacionesImpl();
		
		String[] reparaciones = swReparaciones.todasReparaciones(matricula);
		
		for (String reparacion : reparaciones) {
			System.out.println(reparacion);
		}

	}

}

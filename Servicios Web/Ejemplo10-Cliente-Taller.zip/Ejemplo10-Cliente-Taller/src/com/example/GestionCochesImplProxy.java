package com.example;

public class GestionCochesImplProxy implements com.example.GestionCochesImpl {
  private String _endpoint = null;
  private com.example.GestionCochesImpl gestionCochesImpl = null;
  
  public GestionCochesImplProxy() {
    _initGestionCochesImplProxy();
  }
  
  public GestionCochesImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initGestionCochesImplProxy();
  }
  
  private void _initGestionCochesImplProxy() {
    try {
      gestionCochesImpl = (new com.example.GestionCochesImplServiceLocator()).getGestionCochesImplPort();
      if (gestionCochesImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)gestionCochesImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)gestionCochesImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (gestionCochesImpl != null)
      ((javax.xml.rpc.Stub)gestionCochesImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.example.GestionCochesImpl getGestionCochesImpl() {
    if (gestionCochesImpl == null)
      _initGestionCochesImplProxy();
    return gestionCochesImpl;
  }
  
  public java.lang.String buscarMatricula(java.lang.String arg0) throws java.rmi.RemoteException{
    if (gestionCochesImpl == null)
      _initGestionCochesImplProxy();
    return gestionCochesImpl.buscarMatricula(arg0);
  }
  
  
}
package com.example;

public class GestionReparacionesImplProxy implements com.example.GestionReparacionesImpl {
  private String _endpoint = null;
  private com.example.GestionReparacionesImpl gestionReparacionesImpl = null;
  
  public GestionReparacionesImplProxy() {
    _initGestionReparacionesImplProxy();
  }
  
  public GestionReparacionesImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initGestionReparacionesImplProxy();
  }
  
  private void _initGestionReparacionesImplProxy() {
    try {
      gestionReparacionesImpl = (new com.example.GestionReparacionesImplServiceLocator()).getGestionReparacionesImplPort();
      if (gestionReparacionesImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)gestionReparacionesImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)gestionReparacionesImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (gestionReparacionesImpl != null)
      ((javax.xml.rpc.Stub)gestionReparacionesImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.example.GestionReparacionesImpl getGestionReparacionesImpl() {
    if (gestionReparacionesImpl == null)
      _initGestionReparacionesImplProxy();
    return gestionReparacionesImpl;
  }
  
  public java.lang.String[] todasReparaciones(java.lang.String arg0) throws java.rmi.RemoteException{
    if (gestionReparacionesImpl == null)
      _initGestionReparacionesImplProxy();
    return gestionReparacionesImpl.todasReparaciones(arg0);
  }
  
  
}
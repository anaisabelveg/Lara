package com.example.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.example.persistence.Pedido;
import com.example.persistence.PedidoPK;

public class AppMain {

	public static void main(String[] args) {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata()
				.buildSessionFactory();
		
		// Aqui se abre conexion a la BBDD
		Session session = sf.openSession();
		
		// Abrir una transaccion
		Transaction tx = session.getTransaction();
		
		// Crear 3 pedidos
		Pedido p1 = new Pedido(new PedidoPK(1, 200), 6, 600);
		Pedido p2 = new Pedido(new PedidoPK(1, 210), 5, 400);
		Pedido p3 = new Pedido(new PedidoPK(1, 250), 10, 1000);
		
		try {
			tx.begin();
			
			session.save(p1);
			session.save(p2);
			session.save(p3);
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerrar la conexion
			session.close();
		}

	}

}




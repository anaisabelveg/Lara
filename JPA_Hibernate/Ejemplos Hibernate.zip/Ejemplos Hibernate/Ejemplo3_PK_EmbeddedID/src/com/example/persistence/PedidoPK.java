package com.example.persistence;

import java.io.Serializable;

public class PedidoPK implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6714462669454905952L;
	private Integer numPedido;
	private Integer codigoProducto;
	
	public PedidoPK() {
		// TODO Auto-generated constructor stub
	}

	public PedidoPK(Integer numPedido, Integer codigoProducto) {
		super();
		this.numPedido = numPedido;
		this.codigoProducto = codigoProducto;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigoProducto == null) ? 0 : codigoProducto.hashCode());
		result = prime * result + ((numPedido == null) ? 0 : numPedido.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PedidoPK other = (PedidoPK) obj;
		if (codigoProducto == null) {
			if (other.codigoProducto != null)
				return false;
		} else if (!codigoProducto.equals(other.codigoProducto))
			return false;
		if (numPedido == null) {
			if (other.numPedido != null)
				return false;
		} else if (!numPedido.equals(other.numPedido))
			return false;
		return true;
	}

	public Integer getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(Integer numPedido) {
		this.numPedido = numPedido;
	}

	public Integer getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(Integer codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	@Override
	public String toString() {
		return "PedidoPK [numPedido=" + numPedido + ", codigoProducto=" + codigoProducto + "]";
	}
	
}

package com.example.main;

import java.util.Arrays;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;

import com.example.persistence.Persona;

public class AppMainLeer {

	public static void main(String[] args) {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg2.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata()
				.buildSessionFactory();
		
		// Aqui se abre conexion a la BBDD
		Session session = sf.openSession();
		
		// 1.- Buscar por PK
		String pk = "11111111A";
		Persona persona = session.find(Persona.class, pk);
		System.out.println(persona);
		System.out.println("----------------------------------");

		// 2.- Lecturas HQL
		Query<Persona> query = 
			session.createQuery("from Persona p where p.nombre = :nom");
		query.setParameter("nom", "Juan");
		List<Persona> lista = query.list();
		System.out.println(lista);
		System.out.println("----------------------------------");

		// 3.- Lecturas NamedQuery
		Query queryTodos = session.getNamedQuery("todos");
		List<Persona> todos = queryTodos.getResultList();
		for (Persona persona2 : todos) {
			System.out.println(persona2);
		}
		System.out.println("----------------------------------");
		
				
		Query queryPoblacion = session.createNamedQuery("poblacion");
		queryPoblacion.setParameter("pobl", "Madrid");
		List<Persona> madrid = queryPoblacion.getResultList();
		for (Persona persona2 : madrid) {
			System.out.println(persona2);
		}
		System.out.println("----------------------------------");
		
	
		// Consulta que reciba solo nombre y apellido de las mujeres
		Query queryMujeres = session.createQuery("select p.nombre, p.apellido "
				+ "from Persona p where p.sexo=:sex");
		queryMujeres.setParameter("sex", 'M');
		List<Object[]> mujeres = queryMujeres.getResultList();
		for (Object[] objects : mujeres) {
			System.out.println(Arrays.toString(objects));
		}
		System.out.println("----------------------------------");

		// 4.- Crear queries nativas con sql
		//Query sql = session.createNativeQuery("select * from Ejemplo9_Personas");
		Query sql = session.createNamedQuery("misql");
		List<Object[]> todosSql = sql.getResultList();
		for (Object[] objects : todosSql) {
			System.out.println(Arrays.toString(objects));
		}
		System.out.println("----------------------------------");
		
		
	} // fin del metodo

} // fin de la clase










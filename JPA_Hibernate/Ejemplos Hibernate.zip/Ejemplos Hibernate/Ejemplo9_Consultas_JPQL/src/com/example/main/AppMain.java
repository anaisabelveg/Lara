package com.example.main;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.example.persistence.Direccion;
import com.example.persistence.EstadoCivil;
import com.example.persistence.Persona;

public class AppMain {

	public static void main(String[] args) {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata()
				.buildSessionFactory();
		
		// Aqui se abre conexion a la BBDD
		Session session = sf.openSession();
		
		// Abrir una transaccion
		Transaction tx = session.getTransaction();
		
		
		// Crear 3 personas
		Persona p1 = new Persona("11111111A", "Juan", "Lopez", 27, 'H', 
					new Direccion("Piscis", 56, "Madrid"), 
					EstadoCivil.SOLTERO, 
					new Date("25/4/1992"), 
					"Ingeniero aeronautico, licenciado Universidad Politecnica ....");
		
		Persona p2 = new Persona("22222222B", "Marta", "Sanz", 54, 'M', 
				new Direccion("Mayor", 32, "Madrid"), 
				EstadoCivil.CASADO, 
				new Date("12/7/1982"), 
				"Enfermera, licenciado Universidad Complutense ....");
		
		Persona p3 = new Persona("33333333C", "Luis", "Rodriguez", 34, 'H', 
				new Direccion("Castellana", 84, "Madrid"), 
				EstadoCivil.DIVORCIADO, 
				new Date("12/9/1996"), 
				"Ingeniero Informatico, licenciado Universidad Carlos III ....");
		
		try {
			tx.begin();
			
			session.save(p1);
			session.save(p2);
			session.save(p3);
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerrar la conexion
			session.close();
		}

	}

}




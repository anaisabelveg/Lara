package com.example.persistence;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class MiListener extends EmptyInterceptor implements Serializable {

	@Override
	public boolean onSave(Object entity, // Entidad a persistir
			Serializable id, // PK
			Object[] state, // Valores de la entidad a persistir
			String[] propertyNames, // nombres de las propiedades
			Type[] types) { // tipos de las propiedades

		if (entity instanceof Persona) {
			System.out.println("PK: " + id);

			System.out.println("Propiedades: ");
			for (String prop : propertyNames) {
				System.out.print(prop + " ");
			}
			System.out.println("------------------------");

			System.out.println("Datos: ");
			for (Object dato : state) {
				System.out.print(dato + " ");
			}
			System.out.println("------------------------");

			System.out.println("Tipos: ");
			for (Type tipo : types) {
				System.out.print(tipo + " ");
			}
			System.out.println("------------------------");

			state[0] = "Pepito";

		}

		// Si devuelvo false, los cambios en el estado se ignoran
		// Si devuelvo true, los cambios en el estado se aplican
		return true;
	}

}

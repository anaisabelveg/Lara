package com.example.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.example.persistence.Alumno;
import com.example.persistence.Persona;
import com.example.persistence.Profesor;

public class AppMain {

	public static void main(String[] args) {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure("hibernate.cfg.xml").build();
		SessionFactory sf = new MetadataSources(registry).buildMetadata()
				.buildSessionFactory();
		
		// Aqui se abre conexion a la BBDD
		Session session = sf.openSession();
		
		// Abrir una transaccion
		Transaction tx = session.getTransaction();
		
		try {
			tx.begin();
			
			Persona persona = new Persona(1, "Juan", "Lopez");
			Alumno alumno = new Alumno(2, "Maria", "Sanchez", "JPA e Hibernate");
			Profesor profesor = new Profesor(3, "Luis", "Arias", "Ingeniero Informatico");
			
			session.save(persona);
			session.save(alumno);
			session.save(profesor);
			
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}

package com.example.persistence;

import java.io.Serializable;
import javax.persistence.*;


public class Nif implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private long numero;
	private char letra;
	private Persona persona;
	
	public Nif() {
		super();
	}

	public Nif(long numero, char letra) {
		super();
		this.numero = numero;
		this.letra = letra;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public char getLetra() {
		return letra;
	}

	public void setLetra(char letra) {
		this.letra = letra;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Nif [id=" + id + ", numero=" + numero + ", letra=" + letra + "]";
	}
	
	
   
}









package com.example.persistence;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

public class Persona implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String nombre;
	private String apellido;
	private Nif nif;
	private Set<Telefono> telefonos = new HashSet<>();
	private Set<Coche> coches = new HashSet<>();

	public Persona() {
		super();
	}

	public Persona(String nombre, String apellido, Nif nif) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.nif = nif;
	}
	
	// Metodos de sincronizacion
	// Se crea uno por cada atributo de tipo coleccion
	public void addTelefono(Telefono telefono) {
		this.telefonos.add(telefono);
		telefono.setPersona(this);
	}
	
	public void addCoche(Coche coche) {
		this.coches.add(coche);
		coche.getPropietarios().add(this);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Nif getNif() {
		return nif;
	}

	public void setNif(Nif nif) {
		this.nif = nif;
	}

	public Set<Telefono> getTelefonos() {
		return telefonos;
	}

	public void setTelefonos(Set<Telefono> telefonos) {
		this.telefonos = telefonos;
	}

	public Set<Coche> getCoches() {
		return coches;
	}

	public void setCoches(Set<Coche> coches) {
		this.coches = coches;
	}

	@Override
	public String toString() {
		return "Persona [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", nif=" + nif + ", telefonos="
				+ telefonos + ", coches=" + coches + "]";
	}
	
}









package com.example.persistence;

import java.io.Serializable;
import javax.persistence.*;

public class Telefono implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private long numero;
	private Persona persona;

	public Telefono() {
		super();
	}

	public Telefono(long numero) {
		super();
		this.numero = numero;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public long getNumero() {
		return numero;
	}

	public void setNumero(long numero) {
		this.numero = numero;
	}

	public Persona getPersona() {
		return persona;
	}

	public void setPersona(Persona persona) {
		this.persona = persona;
	}

	@Override
	public String toString() {
		return "Telefono [id=" + id + ", numero=" + numero + "]";
	}
	
   
}









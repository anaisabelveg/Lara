package com.example.persistence;

import java.io.Serializable;

public class Pedido implements Serializable {

	private Integer numPedido;
	private Integer codigoProducto;
	
	private int cantidad;
	private double precio;
	
	private static final long serialVersionUID = 1L;

	public Pedido() {
		super();
	}

	public Pedido(Integer numPedido, Integer codigoProducto, int cantidad, double precio) {
		super();
		this.numPedido = numPedido;
		this.codigoProducto = codigoProducto;
		this.cantidad = cantidad;
		this.precio = precio;
	}

	public Integer getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(Integer numPedido) {
		this.numPedido = numPedido;
	}

	public Integer getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(Integer codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Pedido [numPedido=" + numPedido + ", codigoProducto=" + codigoProducto + ", cantidad=" + cantidad
				+ ", precio=" + precio + "]";
	}
	
	
   
}

package com.example.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.example.persistence.Alumno;
import com.example.persistence.Persona;
import com.example.persistence.Profesor;

public class AppMain {

	public static void main(String[] args) {
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			
			Persona persona = new Persona(1, "Juan", "Lopez");
			Alumno alumno = new Alumno(2, "Maria", "Sanchez", "JPA e Hibernate");
			Profesor profesor = new Profesor(3, "Luis", "Arias", "Ingeniero Informatico");
			
			em.persist(persona);
			em.persist(alumno);
			em.persist(profesor);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}

	}

}

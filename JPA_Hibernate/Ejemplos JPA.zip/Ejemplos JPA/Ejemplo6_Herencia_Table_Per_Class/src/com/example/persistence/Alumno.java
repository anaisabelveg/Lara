package com.example.persistence;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="Ejemplo6_Alumnos")
public class Alumno extends Persona implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String curso;

	public Alumno() {
		super();
	}

	public Alumno(Integer id, String nombre, String apellido, String curso) {
		super(id, nombre, apellido);
		this.curso = curso;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override
	public String toString() {
		return "Alumno [curso=" + curso + ", toString()=" + super.toString() + "]";
	}
	
   
}










package com.example.persistence;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

public class MiListener {
	
	@PrePersist
	@PreUpdate
	public void interceptar(Persona persona) {
		System.out.println("-------------------------");
		System.out.println("Hemos interceptado la entidad persona");
		// Solo quiero demostrar que podemos cambiar valores
		// de la entidad antes de persistir
		persona.setNombre("Pepeito");
		System.out.println("-------------------------");
	}

}

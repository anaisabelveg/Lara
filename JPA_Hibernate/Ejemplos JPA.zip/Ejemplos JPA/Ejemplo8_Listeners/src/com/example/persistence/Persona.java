package com.example.persistence;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Ejemplo8_Personas")
@EntityListeners(MiListener.class)
public class Persona implements Serializable { // Debe ser Serializable

	// Debe tener una PK
	@Id
	@Column(name = "id_nif", nullable = false, unique = true)
	private String nif;

	private String nombre;
	private String apellido;
	private int edad;

	@Column(length = 1)
	private char sexo;

	@Embedded
	private Direccion direccion;

	@Enumerated(EnumType.STRING)
	private EstadoCivil estadoCivil;

	@Temporal(TemporalType.DATE)
	private Date fechaNacimiento;

	private String cv;

	// Debe tener un constructor por defecto
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	public Persona(String nif, String nombre, String apellido, int edad, char sexo, Direccion direccion,
			EstadoCivil estadoCivil, Date fechaNacimiento, String cv) {
		super();
		this.nif = nif;
		this.nombre = nombre;
		this.apellido = apellido;
		this.edad = edad;
		this.sexo = sexo;
		this.direccion = direccion;
		this.estadoCivil = estadoCivil;
		this.fechaNacimiento = fechaNacimiento;
		this.cv = cv;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public Direccion getDireccion() {
		return direccion;
	}

	public void setDireccion(Direccion direccion) {
		this.direccion = direccion;
	}

	public EstadoCivil getEstadoCivil() {
		return estadoCivil;
	}

	public void setEstadoCivil(EstadoCivil estadoCivil) {
		this.estadoCivil = estadoCivil;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getCv() {
		return cv;
	}

	public void setCv(String cv) {
		this.cv = cv;
	}

	@Override
	public String toString() {
		return "Persona [nif=" + nif + ", nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", sexo="
				+ sexo + ", direccion=" + direccion + ", estadoCivil=" + estadoCivil + ", fechaNacimiento="
				+ fechaNacimiento + ", cv=" + cv + "]";
	}

}

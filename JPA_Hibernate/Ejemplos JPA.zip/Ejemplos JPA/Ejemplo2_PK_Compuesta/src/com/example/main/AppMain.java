package com.example.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.example.persistence.Pedido;

public class AppMain {

	public static void main(String[] args) {
		// Cargar los datos de la unidad de persistencia PU declarada
		// en persistence.xml
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// EntityManager es el eje central de JPA
		// Abrir la conexion
		EntityManager em = emf.createEntityManager();
		
		// Abrir una transaccion
		EntityTransaction et = em.getTransaction();
		
		// Crear 3 pedidos
		Pedido p1 = new Pedido(1, 200, 6, 600);
		Pedido p2 = new Pedido(1, 210, 5, 400);
		Pedido p3 = new Pedido(1, 250, 10, 1000);
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Cerrar la conexion
			em.close();
		}

	}

}




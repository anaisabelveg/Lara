package com.example.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.example.persistence.Coche;
import com.example.persistence.Nif;
import com.example.persistence.Persona;
import com.example.persistence.Telefono;

public class AppMain {

	public static void main(String[] args) {
		EntityManagerFactory emf =
				Persistence.createEntityManagerFactory("PU");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		// Crear nifs
		Nif nif1 = new Nif(11111111L, 'A');
		Nif nif2 = new Nif(22222222L, 'B');
		Nif nif3 = new Nif(33333333L, 'C');
		
		// Crear telefonos
		Telefono t1 = new Telefono(656111111L);
		Telefono t2 = new Telefono(656222222L);
		Telefono t3 = new Telefono(656333333L);
		Telefono t4 = new Telefono(656444444L);
		Telefono t5 = new Telefono(656555555L);
		Telefono t6 = new Telefono(656666666L);
		
		// Crear coches
		Coche c1 = new Coche("1111-GHD", "A3");
		Coche c2 = new Coche("2222-GHD", "A4");
		Coche c3 = new Coche("3333-GHD", "A5");
		Coche c4 = new Coche("4444-GHD", "A6");
		
		// Crear personas
		Persona p1 = new Persona("Juan", "Lopez", nif1);
		Persona p2 = new Persona("Maria", "Sanchez", nif2);
		Persona p3 = new Persona("Sara", "Arias", nif3);
		
		// Asignar telefonos a las personas
		p1.addTelefono(t1);
		p1.addTelefono(t2);
		
		p2.addTelefono(t3);
		p2.addTelefono(t4);
		
		p3.addTelefono(t5);
		p3.addTelefono(t6);
		
		// Asignar coches a las personas
		p1.addCoche(c1);
		p1.addCoche(c2);
		p1.addCoche(c3);
		
		p2.addCoche(c3);
		p2.addCoche(c4);
		
		p3.addCoche(c2);
		p3.addCoche(c4);
		
		try {
			et.begin();
			
			// Persistir personas
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			em.close();
		}

	}

}

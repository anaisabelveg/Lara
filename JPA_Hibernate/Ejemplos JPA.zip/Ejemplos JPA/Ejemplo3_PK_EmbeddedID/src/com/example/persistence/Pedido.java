package com.example.persistence;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "Ejemplo3_Pedidos")
public class Pedido implements Serializable {

	@EmbeddedId
	private PedidoPK pedidoPK;

	private int cantidad;
	private double precio;

	private static final long serialVersionUID = 1L;

	public Pedido() {
		super();
	}

	public Pedido(PedidoPK pedidoPK, int cantidad, double precio) {
		super();
		this.pedidoPK = pedidoPK;
		this.cantidad = cantidad;
		this.precio = precio;
	}

	public PedidoPK getPedidoPK() {
		return pedidoPK;
	}
	
	public void setPedidoPK(PedidoPK pedidoPK) {
		this.pedidoPK = pedidoPK;
	}

	public int getCantidad() {
		return cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Pedido [pedidoPK=" + pedidoPK + ", cantidad=" + cantidad + ", precio=" + precio + "]";
	}

	

}

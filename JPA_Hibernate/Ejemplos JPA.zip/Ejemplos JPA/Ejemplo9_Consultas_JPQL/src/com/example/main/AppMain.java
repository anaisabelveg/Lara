package com.example.main;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.example.persistence.Direccion;
import com.example.persistence.EstadoCivil;
import com.example.persistence.Persona;

public class AppMain {

	public static void main(String[] args) {
		// Cargar los datos de la unidad de persistencia PU declarada
		// en persistence.xml
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		
		// EntityManager es el eje central de JPA
		// Abrir la conexion
		EntityManager em = emf.createEntityManager();
		
		// Abrir una transaccion
		EntityTransaction et = em.getTransaction();
		
		// Crear 3 personas
		Persona p1 = new Persona("11111111A", "Juan", "Lopez", 27, 'H', 
					new Direccion("Piscis", 56, "Madrid"), 
					EstadoCivil.SOLTERO, 
					new Date("25/4/1992"), 
					"Ingeniero aeronautico, licenciado Universidad Politecnica ....");
		
		Persona p2 = new Persona("22222222B", "Marta", "Sanz", 54, 'M', 
				new Direccion("Mayor", 32, "Madrid"), 
				EstadoCivil.CASADO, 
				new Date("12/7/1982"), 
				"Enfermera, licenciado Universidad Complutense ....");
		
		Persona p3 = new Persona("33333333C", "Luis", "Rodriguez", 34, 'H', 
				new Direccion("Castellana", 84, "Madrid"), 
				EstadoCivil.DIVORCIADO, 
				new Date("12/9/1996"), 
				"Ingeniero Informatico, licenciado Universidad Carlos III ....");
		
		try {
			et.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			et.commit();
		} catch (Exception e) {
			et.rollback();
			e.printStackTrace();
		} finally {
			// Cerrar la conexion
			em.close();
		}

	}

}




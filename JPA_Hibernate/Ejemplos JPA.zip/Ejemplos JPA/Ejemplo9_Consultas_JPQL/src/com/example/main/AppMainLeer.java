package com.example.main;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.example.persistence.Persona;

public class AppMainLeer {

	public static void main(String[] args) {
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU_Leer");
		EntityManager em = emf.createEntityManager();
		
		// Al ser lecturas no se necesita transaccion
		
		// 1.- Buscar por PK
		String pk = "11111111A";
		Persona persona = em.find(Persona.class, pk);
		System.out.println(persona);
		System.out.println("----------------------------------");
		
		// 2.- Lecturas JPQL
		Query query = em.createQuery("select p from Persona p where p.nombre = :nom");
		query.setParameter("nom", "Juan");
		List<Persona> lista = query.getResultList();
		System.out.println(lista);
		System.out.println("----------------------------------");
		
		// 3.- Lecturas NamedQuery
		Query queryTodos = em.createNamedQuery("todos");
		List<Persona> todos = queryTodos.getResultList();
		for (Persona persona2 : todos) {
			System.out.println(persona2);
		}
		System.out.println("----------------------------------");
		
		Query queryPoblacion = em.createNamedQuery("poblacion");
		queryPoblacion.setParameter("pobl", "Madrid");
		List<Persona> madrid = queryPoblacion.getResultList();
		for (Persona persona2 : madrid) {
			System.out.println(persona2);
		}
		System.out.println("----------------------------------");
		
		// Consulta que reciba solo nombre y apellido de las mujeres
		Query queryMujeres = em.createQuery("select p.nombre, p.apellido "
				+ "from Persona p where p.sexo=:sex");
		queryMujeres.setParameter("sex", 'M');
		List<Object[]> mujeres = queryMujeres.getResultList();
		for (Object[] objects : mujeres) {
			System.out.println(Arrays.toString(objects));
		}
		System.out.println("----------------------------------");
		
		// 4.- Crear queries nativas con sql
		Query sql = em.createNativeQuery("select * from Ejemplo1_Personas");
		List<Object[]> todosSql = sql.getResultList();
		for (Object[] objects : todosSql) {
			System.out.println(Arrays.toString(objects));
		}
		System.out.println("----------------------------------");
	}

}










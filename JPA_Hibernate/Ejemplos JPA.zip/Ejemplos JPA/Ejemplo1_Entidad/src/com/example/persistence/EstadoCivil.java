package com.example.persistence;

public enum EstadoCivil {
	SOLTERO, CASADO, VIUDO, DIVORCIADO, PAREJA_HECHO;
}

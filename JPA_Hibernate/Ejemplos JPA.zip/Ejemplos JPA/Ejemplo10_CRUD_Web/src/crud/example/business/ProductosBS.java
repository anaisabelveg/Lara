package crud.example.business;

import java.util.ArrayList;
import java.util.List;

import crud.example.models.ProductoDTO;
import crud.example.persistence.Producto;
import crud.example.persistence.ProductosDAO;

public class ProductosBS {
	
	private ProductosDAO dao = new ProductosDAO();
	
	public List<ProductoDTO> todos(){
		List<ProductoDTO> lista = new ArrayList<>();
		
		for (Producto entidad : dao.consultarTodos()) {
			lista.add(convertEntityDTO(entidad));
		}
		
		return lista;
	}
	
	public ProductoDTO buscar(int id) {
		return convertEntityDTO(dao.buscarProducto(id));
	}
	
	public boolean nuevo(ProductoDTO nuevo) {
		return dao.alta(convertDTOEntity(nuevo));
	}
	
	public boolean delete(int id) {
		return dao.eliminar(id);
	}
	
	public boolean modificar(ProductoDTO productoModificado) {
		return dao.modificar(convertDTOEntity(productoModificado));
	}
	
	private Producto convertDTOEntity(ProductoDTO productoDTO) {
		Producto producto = new Producto(productoDTO.getId(),
				productoDTO.getDescripcion(), productoDTO.getPrecio());
		return producto;
	}
	
	private ProductoDTO convertEntityDTO(Producto producto) {
		ProductoDTO productoDTO = new ProductoDTO( producto.getID(),
				producto.getDescripcion(), producto.getPrecio());
		return productoDTO;
	}

}

package crud.example.models;

// Data Transfer Object
public class ProductoDTO {
	
	private int id;
	private String descripcion;
	private double precio;
	
	public ProductoDTO() {
		// TODO Auto-generated constructor stub
	}

	public ProductoDTO(String descripcion, double precio) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
	}
	
	public ProductoDTO(int id, String descripcion, double precio) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "ProductoDTO [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}
	
	

}

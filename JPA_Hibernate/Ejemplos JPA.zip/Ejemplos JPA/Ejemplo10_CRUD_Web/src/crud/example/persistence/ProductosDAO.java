package crud.example.persistence;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ProductosDAO {
	
	private EntityManager em;
	
	public List<Producto> consultarTodos(){
		abrirConexion();
		Query query = em.createQuery("select p from Producto p");
		List<Producto> productos = query.getResultList();
		cerrarConexion();
		return productos;
	}
	
	public Producto buscarProducto(int id){
		abrirConexion();
		Producto producto = em.find(Producto.class, id);
		cerrarConexion();
		return producto;
	}
	
	public boolean alta(Producto producto) {
		boolean insertado = false;
		abrirConexion();
		EntityTransaction et = em.getTransaction();
		try {
			et.begin();
			em.persist(producto);
			et.commit();
			insertado = true;
		} catch (Exception ex) {
			et.rollback();
			ex.printStackTrace();
		}		
		cerrarConexion();
		return insertado;
	}
	
	public boolean eliminar(int id) {
		boolean eliminado = false;
		abrirConexion();
		EntityTransaction et = em.getTransaction();
		try {
			et.begin();
			em.remove(em.find(Producto.class, id));
			et.commit();
			eliminado = true;
		} catch (Exception ex) {
			et.rollback();
			ex.printStackTrace();
		}		
		cerrarConexion();
		return eliminado;
	}
	
	public boolean modificar(Producto producto) {
		boolean modificado = false;
		abrirConexion();
		EntityTransaction et = em.getTransaction();
		try {
			et.begin();
			em.merge(producto);
			et.commit();
			modificado = true;
		} catch (Exception ex) {
			et.rollback();
			ex.printStackTrace();
		}		
		cerrarConexion();
		return modificado;
	}
	
	private void abrirConexion() {
		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("PU");
		em = emf.createEntityManager();
	}
	
	private void cerrarConexion() {
		em.close();
	}


}

package crud.example.persistence;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name="Productos")
public class Producto implements Serializable {

	@Id
	@Column(name="ID")
	private Integer ID;
	
	@Column(name="DESCRIPCION")
	private String descripcion;
	
	@Column(name="PRECIO")
	private double precio;
	
	private static final long serialVersionUID = 1L;

	public Producto() {
		super();
	}

	public Producto(String descripcion, double precio) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public Producto(Integer iD, String descripcion, double precio) {
		super();
		ID = iD;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public Integer getID() {
		return ID;
	}

	public void setID(Integer iD) {
		ID = iD;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [ID=" + ID + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}
	
}

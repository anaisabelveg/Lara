package crud.example.web;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import crud.example.business.ProductosBS;
import crud.example.models.ProductoDTO;

/**
 * Servlet implementation class ProductosServlet
 */
@WebServlet("/servlet")
public class ProductosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		// 1.- Reconocer que me estan pidiendo
		String opcion = request.getParameter("op");
		String vista = "/index.html";
		
		ProductosBS bs = new ProductosBS();
		
		switch (opcion) {
		case "1":  // todos
			request.setAttribute("lista", bs.todos());
			vista = "/mostrarTodos.jsp";
			break;
		case "2":  // buscar uno
			int id = Integer.parseInt(request.getParameter("codigo"));
			ProductoDTO producto = bs.buscar(id);
			request.setAttribute("producto", producto);
			vista = "/mostrarProducto.jsp";
			break;
		case "3":  // alta
			double precio = Double.parseDouble(request.getParameter("precio"));
			String descripcion = request.getParameter("descripcion");
			ProductoDTO nuevo = new ProductoDTO(descripcion, precio);
			bs.nuevo(nuevo);
			break;
		case "4":  // borrar
			id = Integer.parseInt(request.getParameter("codigo"));
			bs.delete(id);
			break;
		case "5":  // modificar
			id = Integer.parseInt(request.getParameter("codigo"));
			descripcion = request.getParameter("descripcion");
			precio = Double.parseDouble(request.getParameter("precio"));
			ProductoDTO modificado = new ProductoDTO(id, descripcion, precio);
			bs.modificar(modificado);
			break;	
		}
		
		RequestDispatcher rd = request.getRequestDispatcher(vista);
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			doGet(request, response);
	}

}

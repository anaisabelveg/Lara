package com.example.persistence;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@DiscriminatorValue(value="Profe")
@Table(name="Ejemplo5_Profesores")
public class Profesor extends Persona implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String titulacion;

	public Profesor() {
		super();
	}

	public Profesor(Integer id, String nombre, String apellido, String titulacion) {
		super(id, nombre, apellido);
		this.titulacion = titulacion;
	}

	public String getTitulacion() {
		return titulacion;
	}

	public void setTitulacion(String titulacion) {
		this.titulacion = titulacion;
	}

	@Override
	public String toString() {
		return "Profesor [titulacion=" + titulacion + ", toString()=" + super.toString() + "]";
	}
	
	
   
}

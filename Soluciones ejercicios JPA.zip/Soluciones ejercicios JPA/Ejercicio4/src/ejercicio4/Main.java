/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ejercicio4;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

// Cambiar en función del tipo de ejecución
//import modelo.singletable.Coche;
//import modelo.singletable.Camion;

import modelo.Coche;
import modelo.Camion;


/**
 *
 * @author Administrador
 */
public class Main {
    
    private static EntityManagerFactory emf;
    private static EntityManager em;
    private static EntityTransaction tx;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear EntityManagerFactory
        emf = Persistence.createEntityManagerFactory("Ejercicio4PU");
        
        // Crear EntityManager
        em = emf.createEntityManager();
        
        // Crear transacción
        tx = em.getTransaction();
        
        // Crear objetos => NEW
        Coche co1 = new Coche("FORD MONDEO", 205F, 130, 4, 4.20F);
        Coche co2 = new Coche("SEAT LEON", 220.0F, 150, 5, 4.0F);
        Coche co3 = new Coche("MERCEDES CLK", 247F, 280, 3, 4.0F);
        Camion ca1 = new Camion("IBECO 300", 150F, 300, 3000, 14000);
        Camion ca2 = new Camion("RENAULT F2000", 140F, 250, 4000, 9000);
        
        try {
            // Iniciar transacción
            tx.begin();
            
            // Crear entidades en la base de datos
            em.persist(co1);
            em.persist(co2);
            em.persist(co3);
            em.persist(ca1);
            em.persist(ca2);
            
            // Commit
            tx.commit();
            
            System.out.println(co1);
            System.out.println(co2);
            System.out.println(co3);
            System.out.println(ca1);
            System.out.println(ca2);
        }
        catch (Exception e){
            e.printStackTrace();
            tx.rollback();
        }
        finally {
            em.close();
            emf.close();
        }
    }

}

package ejercicio2;

import app.persistencia.Libro;
import app.persistencia.LibroPK;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

    public static void main(String[] args) {
        // EntityManagerFactory para escribir
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("UP1");

        // EntityManagerFactory para leer
        EntityManagerFactory emf2 = Persistence.createEntityManagerFactory("UP1");

        // Almacenar 5 libros
        System.out.println("Almacenando libros ------------------------------");
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        tx.begin();
            em.persist(new Libro(new LibroPK("Los pilares de la tierra", "Ken Follet"), "Descripcion 1", "Resumen 1" ));
            em.persist(new Libro(new LibroPK("La caida de los gigantes", "Ken Follet"),"Descripcion 2", "Resumen 2"));
            em.persist(new Libro(new LibroPK("El tiempo entre costuras", "Maria Dueñas"),"Descripcion 3", "Resumen 3"));
            em.persist(new Libro(new LibroPK("Mision olvido", "Maria Dueñas"),"Descripcion 4", "Resumen 4"));
            em.persist(new Libro(new LibroPK("Como agua para chocolate", "Isabel Allende"),"Descripcion 5", "Resumen 5"));
        tx.commit();
        

        
        System.out.println("Consultando todos los libros --------------------");
        EntityManager newEm3 = emf2.createEntityManager();
        List<Libro> libros = newEm3.createQuery("select p from Libro p order by p.libroPk.titulo asc").getResultList();
        for (Libro p : libros) {
            System.out.println(p);
        }
        
        System.out.println("Consultando los libros de Ken Follet --------------------");
        Query q1 = newEm3.createQuery("select p from Libro p where p.libroPk.autor = :autor");
        q1.setParameter("autor", "Ken Follet");
        List<Libro> librosKen = q1.getResultList();
        for (Libro p : librosKen) {
            System.out.println(p);
        }

        System.out.println("Eliminar el libro 'El tiempo entre costuras' --------------------");
        Query q2 = em.createQuery("delete from Libro p where p.libroPk.titulo = :title");
        q2.setParameter("title", "El tiempo entre costuras");
        tx.begin();
        q2.executeUpdate();
        tx.commit();

        System.out.println("Modificar la descripcion del libro 'Los Pilares de la tierra' --------------------");
        Query q3 = em.createQuery("update Libro p SET p.descripcion = :desc WHERE p.libroPk.titulo = :title");
        q3.setParameter("desc", "Nueva descripcion");
        q3.setParameter("title", "Los pilares de la tierra");
        tx.begin();
        q3.executeUpdate();
        tx.commit();

        em.close();
        newEm3.close();
        emf.close();
        emf2.close();

    }
}

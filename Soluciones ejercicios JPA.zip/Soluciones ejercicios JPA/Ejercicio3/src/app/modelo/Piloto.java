/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package app.modelo;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 *
 * @author profesor
 */
@Entity
@Table(name="ejemplo3_pilotos")
public class Piloto implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name="ID")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    private String nombre;
    private int edad;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="FACTURACION_ID",referencedColumnName="ID")
    private Facturacion facturacion;

    @OneToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="NIF_ID",referencedColumnName="ID")
    private Nif nif;

    @ManyToOne(cascade={CascadeType.MERGE,CascadeType.PERSIST,
                        CascadeType.REFRESH})
    @JoinColumn(name="ESCUDERIA_ID", referencedColumnName="ID")
    private Escuderia escuderia;

    @OneToMany(mappedBy="piloto", cascade=CascadeType.ALL)
    private Set<Telefono> telefonos = new HashSet<Telefono>();

    @ManyToMany(cascade={CascadeType.MERGE,CascadeType.PERSIST,
                         CascadeType.REFRESH})
    @JoinTable(name="ejemplo6_pilotos_temporadas",
         joinColumns=@JoinColumn(name="PILOTO_ID",referencedColumnName="ID"),
         inverseJoinColumns=@JoinColumn(name="TEMPORADA_ID",
                                        referencedColumnName="ID"))
    private Set<Temporada> temporadas = new HashSet<Temporada>();

    public Piloto() {
    }

    public Piloto(String nombre, int edad, Nif nif) {
        this.nombre = nombre;
        this.edad = edad;
        this.nif = nif;
    }

    public void addTemporada(Temporada t){
        temporadas.add(t);
        t.getPilotos().add(this);
    }

    public void addTelefono(Telefono t){
        telefonos.add(t);
        t.setPiloto(this);
    }

    public void addFacturacion(Facturacion fact){
        setFacturacion(fact);
        fact.setPiloto(this);
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Escuderia getEscuderia() {
        return escuderia;
    }

    public void setEscuderia(Escuderia escuderia) {
        this.escuderia = escuderia;
    }

    public Facturacion getFacturacion() {
        return facturacion;
    }

    public void setFacturacion(Facturacion facturacion) {
        this.facturacion = facturacion;
        
    }

    public Nif getNif() {
        return nif;
    }

    public void setNif(Nif nif) {
        this.nif = nif;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Set<Telefono> getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(Set<Telefono> telefonos) {
        this.telefonos = telefonos;
    }

    public Set<Temporada> getTemporadas() {
        return temporadas;
    }

    public void setTemporadas(Set<Temporada> temporadas) {
        this.temporadas = temporadas;
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Piloto other = (Piloto) obj;
        if (this.id != other.id && (this.id == null || !this.id.equals(other.id))) {
            return false;
        }
        if ((this.nombre == null) ? (other.nombre != null) : !this.nombre.equals(other.nombre)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Piloto{" + "id=" + id + "nombre=" + nombre + "edad=" + edad + "facturacion=" + facturacion + "nif=" + nif + "escuderia=" + escuderia + "telefonos=" + telefonos + "temporadas=" + temporadas + '}';
    }

    

}

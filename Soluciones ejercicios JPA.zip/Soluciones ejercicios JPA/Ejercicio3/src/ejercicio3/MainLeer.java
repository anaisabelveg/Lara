package ejercicio3;

import app.modelo.Escuderia;
import app.modelo.Piloto;
import app.modelo.Telefono;
import app.modelo.Temporada;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class MainLeer {

    public static void main(String[] args) {

        EntityManagerFactory emf = 
                Persistence.createEntityManagerFactory("PU2");
        EntityManager em = emf.createEntityManager();

        try{
            // 1.- Mostrar los pilotos que pertenecen a una determinada temporada
            Query q1 =
                em.createQuery("select t from Temporada t "
                    + "where t.inicio=:ini AND t.fin=:fin");
            q1.setParameter("ini", 2010);
            q1.setParameter("fin", 2011);
            Temporada temporada = (Temporada) q1.getSingleResult();
            for(Piloto p : temporada.getPilotos()){
                System.out.println(p);
            }
            System.out.println("=============================================");

            // 2.- Mostrar los pilotos de una escuderia
            Query q2 = em.createQuery("select e from Escuderia e where "
                    + " e.nombre = :nom");
            q2.setParameter("nom", "Ferrari");
            Escuderia ferrari = (Escuderia) q2.getSingleResult();
            for (Piloto p : ferrari.getPilotos()){
                System.out.println(p);
            }
            System.out.println("=============================================");

            // 3.- Mostrar los pilotos con un sueldo superior a una cifra
            Query q3 = em.createQuery("select p from Piloto p "
                    + "where p.facturacion.sueldo > 4000000");
            List<Piloto> ricos = q3.getResultList();
            for(Piloto p : ricos){
                System.out.println(p);
            }
            System.out.println("=============================================");

            // 4.- Mostrar los pilotos que cobren por publicidad entre 2 valores
            Query q4 = em.createQuery("select p from Piloto p "
                    + "where p.facturacion.publicidad "
                    + "BETWEEN  :min AND :max");
            q4.setParameter("min", 1500000);
            q4.setParameter("max", 4000000);
            List<Piloto> masRicos = q4.getResultList();
            for(Piloto p: masRicos){
                System.out.println(p);
            }
            System.out.println("=============================================");


            // 5.- Mostrar los pilotos que no sean de la escuderia italiana
            Query q5 = em.createQuery("select p from Piloto p where "
                    + "p.escuderia.pais NOT IN (:pais)");
            q5.setParameter("pais", "Italia");
            List<Piloto> noItalianos = q5.getResultList();
            for(Piloto p : noItalianos){
                System.out.println(p);
            }
            System.out.println("=============================================");

            // 6.- Mostrar todos los telefonos de Alonso
            Query q6 = em.createQuery("select t from Telefono t where "
                    + "t.piloto.nombre = :nom ").setParameter("nom", "Alonso");
            List<Telefono> telAlonso = q6.getResultList();
            for(Telefono tf : telAlonso){
                System.out.println(tf);
            }
            System.out.println("=============================================");

            


        }catch(Exception ex){
            ex.printStackTrace();
        }finally{
            em.close();
            emf.close();
        }
    }
}

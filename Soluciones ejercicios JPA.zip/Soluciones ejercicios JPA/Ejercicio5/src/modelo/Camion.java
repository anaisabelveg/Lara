/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;


/**
 *
 * @author Administrador
 */
@Entity
@DiscriminatorValue(value="CAMION")
public class Camion extends Vehiculo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Column(name="TARA")
    private int tara;
    
    @Column(name="PMA")
    private int pma;

    public Camion() {
    }

    public Camion(String modelo, float velocidad, int potencia, int tara, int pma) {
        this.modelo = modelo;
        this.velocidad = velocidad;
        this.potencia = potencia;
        this.tara = tara;
        this.pma = pma;
    }       

    public int getTara() {
        return tara;
    }

    public void setTara(int tara) {
        this.tara = tara;
    }

    public int getPma() {
        return pma;
    }

    public void setPma(int pma) {
        this.pma = pma;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Camion)) {
            return false;
        }
        Camion other = (Camion) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Camion{" + "tara=" + tara + "pma=" + pma + '}';
    }

    
}

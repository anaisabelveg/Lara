package ejercicio1;

import app.modelo.Persona;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

    public static void main(String[] args) {
        // Arrancar EntityManagerFactory para escritura
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("unidadPersistente1");

        // Guardar 20 personas
        System.out.println("Primera unidad de trabajo");
        EntityManager newEm = emf.createEntityManager();
        EntityTransaction newTx = newEm.getTransaction();
        newTx.begin();
        for (int i = 1; i <= 20; i++) {
            newEm.persist(new Persona("Persona " + i, "dni " + i));
        }
        newTx.commit();
        newEm.close();

        // Arrancar EntityManagerFactory para lecturas
        EntityManagerFactory emf2 = Persistence.createEntityManagerFactory("unidadPersistente2");

        // recuperar todas las personas de la base de datos ordenados por su codigo de forma descendente
        System.out.println("Segunda unidad de trabajo");
        EntityManager newEm3 = emf2.createEntityManager();

        Query consulta = newEm3.createQuery("select p from Persona p order by p.codigo desc");
        List<Persona> personas = consulta.getResultList();

        System.out.println(personas.size() + " persona(s) encontradas.");
        for (Persona p : personas) {
            System.out.println(p);
        }
        newEm3.close();
        emf2.close();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package modelo;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import listeners.ListenerSubclasses;


/**
 *
 * @author Administrador
 */
@Entity
@DiscriminatorValue(value="COCHE")
@PrimaryKeyJoinColumn(name="ID")
@Table(name="ejemplo6_coches_joined")
@EntityListeners(ListenerSubclasses.class)
public class Coche extends Vehiculo implements Serializable {
    private static final long serialVersionUID = 1L;
    
    @Column(name="PUERTAS")
    private int puertas;
    
    @Column(name="LONGITUD")
    private float longitud;

    public Coche() {
    }

    public Coche(String modelo, float velocidad, int potencia, int puertas, float longitud) {
        this.modelo = modelo;
        this.velocidad = velocidad;
        this.potencia = potencia;
        this.puertas = puertas;
        this.longitud = longitud;
    }
        
    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public float getLongitud() {
        return longitud;
    }

    public void setLongitud(float longitud) {
        this.longitud = longitud;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Coche)) {
            return false;
        }
        Coche other = (Coche) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Coche{" + "puertas=" + puertas + " longitud=" + longitud + '}';
    }

    

}

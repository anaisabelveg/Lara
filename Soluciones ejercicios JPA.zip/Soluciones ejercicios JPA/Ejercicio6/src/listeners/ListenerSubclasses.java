/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package listeners;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import modelo.Vehiculo;
import modelo.Coche;
import modelo.Camion;

/**
 *
 * @author Administrador
 */
public class ListenerSubclasses {

    public ListenerSubclasses() {
    }
    
    @PrePersist
    @PreUpdate
    public void monitorizar(Vehiculo v) {
        if (v instanceof Coche)
            System.out.println("REALIZANDO ACTUALIZACIÓN EN BBDD DE COCHE");
        else if (v instanceof Camion)
            System.out.println("REALIZANDO ACTUALIZACIÓN EN BBDD DE CAMIÓN");
        else
            System.out.println("REALIZANDO ACTUALIZACIÓN EN BBDD DE VEHICULO");
    }

}

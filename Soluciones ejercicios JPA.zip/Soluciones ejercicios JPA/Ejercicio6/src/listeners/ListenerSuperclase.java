/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package listeners;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import modelo.Vehiculo;

/**
 *
 * @author Administrador
 */
public class ListenerSuperclase {

    public ListenerSuperclase() {
    }
    
    @PrePersist
    @PreUpdate
    public void monitorizar (Vehiculo v) {
        System.out.println("REALIZANDO ACTUALIZACIÓN EN BBDD DE VEHICULO");
    }
}

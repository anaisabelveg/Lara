package es.lara;

public class Monedas {
	
	private int quinientos;
	private int doscientos;
	private int cien;
	private int cincuenta;
	private int veinte;
	private int diez;
	private int cinco;
	private int dos;
	private int uno;
	private int cincuentaCent;
	private int veinteCent;
	private int diezCent;
	private int cincoCent;
	private int dosCent;
	private int centimo;
	
	public void devolverCambio(double pago, double importe) {
		// Calculamos el cambio a devolver
		double cambio = pago-importe;
		
		quinientos = (int)(cambio / 500); 
		cambio = cambio % 500;
		
		doscientos = (int)(cambio / 200); 
		cambio = cambio % 200;
		
		cien = (int)(cambio / 100); 
		cambio = cambio % 100;
		
		cincuenta = (int)(cambio / 50); 
		cambio = cambio % 50;
		
		veinte = (int)(cambio / 20); 
		cambio = cambio % 20;
		
		diez = (int)(cambio / 10); 
		cambio = cambio % 10;
		
		cinco = (int)(cambio / 5); 
		cambio = cambio % 5;
		
		dos = (int)(cambio / 2); 
		cambio = cambio % 2;
		
		uno = (int)(cambio / 1); 
		cambio = cambio % 1;
		
		cincuentaCent = (int)(cambio / 0.5); 
		cambio = cambio % 0.5;
		
		veinteCent = (int)(cambio / 0.2); 
		cambio = cambio % 0.2;
		
		diezCent = (int)(cambio / 0.1); 
		cambio = cambio % 0.1;
		
		cincoCent = (int)(cambio / 0.05); 
		cambio = cambio % 0.05;
		
		dosCent = (int)(cambio / 0.02); 
		cambio = cambio % 0.02;
		
		
		//centimo = (int)(cambio / 0.01); 
		if (cambio > 0) {
			centimo = 1;
		}
		
		mostrarCambio();
	}
	
	public void mostrarCambio() {
		System.out.println("quinientos=" + quinientos + 
				"\n doscientos=" + doscientos + "\n cien=" + cien +
				"\n cincuenta=" + cincuenta + "\n veinte=" + veinte + 
				"\n diez=" + diez + "\n cinco=" + cinco + 
				"\n dos=" + dos + "\n uno="+ uno + 
				"\n cincuentaCent=" + cincuentaCent + 
				"\n veinteCent=" + veinteCent + "\n diezCent=" + diezCent +
				"\n cincoCent=" + cincoCent + "\n dosCent=" + dosCent + 
				"\n centimo=" + centimo);
	}


}
















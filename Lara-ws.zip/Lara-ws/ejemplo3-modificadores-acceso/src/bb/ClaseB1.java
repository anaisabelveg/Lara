package bb;

public class ClaseB1 extends ClaseB {
	
	public void probarAccesos() {
		
		publica = "Tengo acceso a la publica";
		defecto = "Acceso permitido por estar en el mismo paquete";
		protegida = "Permitido por ser subclase de ClaseB";
	}

}

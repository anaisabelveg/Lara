package com.example.models;

public class Direccion {
	
	public String calle;
	public int numero;
	public int piso;
	public char letra;
	public int codigoPostal;
	public String poblacion;
	public String provincia;
	public String pais;

}

package com.example;

public class Main {

	public static void main(String[] args) {
		System.out.println("Bienvenidos al curso de Java !!");
		
		int numero1 = 5;
		int numero2 = 7;
		
		// syso + ctrl + space 
		System.out.println("La suma de " + numero1 + " y " + numero2 + 
				" es: " + (numero1 + numero2));

	} // aqui termina el metodo main

} // fin de la clase

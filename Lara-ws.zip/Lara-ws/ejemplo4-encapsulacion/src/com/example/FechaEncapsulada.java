package com.example;

// Una clase encapsulada es aquella que tiene
// todos sus atributos como privados y se
// accede a ellos a traves de los métodos get y set.
public class FechaEncapsulada {

	private int dia;
	private int mes;
	private int anyo;

	public int getDia() {
		return dia;
	}

	public void setDia(int dia) {
		
		if (dia > 0 && dia < 32) {
			this.dia = dia;
		} else {
			System.out.println("Dia no valido");
		}
		
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes > 0 && mes < 13) {
			this.mes = mes;
		} else {
			System.out.println("Mes invalido");
		}
		
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		this.anyo = anyo;
	}

	public void mostrarFecha() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}

package com.example;

public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Fecha fecha1 =new Fecha();
		fecha1.dia = -45677;
		fecha1.mes = 567899;
		fecha1.anyo = -234;
		fecha1.mostrarFecha();
		
		FechaEncapsulada fecha2 = new FechaEncapsulada();
		fecha2.setDia(-45677);
		fecha2.setMes(567899);
		fecha2.setAnyo(-234);
		fecha2.mostrarFecha();
		
		

	}

}

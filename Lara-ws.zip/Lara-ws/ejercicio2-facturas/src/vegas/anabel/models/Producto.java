package vegas.anabel.models;

public class Producto {

	public int ID;
	public String descripcion;
	public double precio;
	
	public Producto() {
		super();
	}

	public Producto(int iD, String descripcion, double precio) {
		super();
		ID = iD;
		this.descripcion = descripcion;
		this.precio = precio;
	}


	@Override
	public String toString() {
		// devuelve un String con la representacion
		// textual del objeto
		return "Producto [ID=" + ID + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}

}

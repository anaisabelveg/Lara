package vegas.anabel.main;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import vegas.anabel.modelos.Alumno;
import vegas.anabel.persistencia.AlumnosDAO;

public class AppMain {

	public static void main(String[] args) {
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		AlumnosDAO dao = (AlumnosDAO) context.getBean("dao");
		
		System.out.println("Todos los alumnos");
		System.out.println("-----------------");
		for(Alumno alum : dao.consultarTodos()) {
			System.out.println(alum);
		}
		
		System.out.println("Alumno encontrado");
		System.out.println("-----------------");
		System.out.println(dao.buscarAlumno(1));
		
		//dao.eliminar(3);
		dao.alta(new Alumno(3,"Ismael","Gonzalez", new Date(2019, 7, 20), true, 6.3));

		dao.modificarNota(1, 8);
	}

}









package vegas.anabel.persistencia;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import vegas.anabel.modelos.Alumno;

public class AlumnosDAO {

	private JdbcTemplate template;
	private RowMapper<Alumno> mapeadorAlumno;

	@Transactional
	public void modificarNota(int id, double nuevaNota) {
		String sql = "update Alumnos set NOTA=? where idAlumnos=?";
		template.update(sql, nuevaNota, id);
	}

	@Transactional
	public void eliminar(int id) {
		String sql = "delete from Alumnos where idAlumnos=?";
		template.update(sql, id);
	}

	@Transactional
	public void alta(Alumno nuevo) {
		String sql = "insert into Alumnos values (?,?,?,?,?,?)";
		template.update(sql, 5,"Prueba","xxxx", 
				new Date(2020, 11, 10), true, 6.4);
		template.update(sql, nuevo.getID(), nuevo.getNombre(), nuevo.getApellido(),
				new java.sql.Date(nuevo.getFechaNacimiento().getTime()), nuevo.isRepetidor(), nuevo.getNota());
	}

	public Alumno buscarAlumno(int id) {
		String sql = "select * from Alumnos where idAlumnos = ?";
		return template.queryForObject(sql, new Object[] { id }, mapeadorAlumno);
	}

	public List<Alumno> consultarTodos() {
		return template.query("select * from Alumnos", mapeadorAlumno);
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	public RowMapper<Alumno> getMapeadorAlumno() {
		return mapeadorAlumno;
	}

	public void setMapeadorAlumno(RowMapper<Alumno> mapeadorAlumno) {
		this.mapeadorAlumno = mapeadorAlumno;
	}


}

import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  alumnos: any = [
    {id:1,valoracion:'alta',nombre:'Juan',apellido:'Lopez',nota:7.5,repetidor:false},
    {id:2,valoracion:'media',nombre:'Maria',apellido:'Sanchez',nota:5.8,repetidor:false},
    {id:3,valoracion:'baja',nombre:'Elena',apellido:'Arias',nota:3.2,repetidor:true},
    {id:4,valoracion:'media',nombre:'Roberto',apellido:'Rodriguez',nota:6.4,repetidor:true},
    {id:5,valoracion:'baja',nombre:'Javier',apellido:'Martin',nota:4.8,repetidor:false},
    {id:6,valoracion:'alta',nombre:'Marta',apellido:'Gonzalez',nota:9.3,repetidor:false}
  ];
}

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NegocioService {

  cervezas: any = [
    {id:1,marca:'Cruzcampo',precio:1.50,ibu:2,existencias:true},
    {id:2,marca:'Heineken',precio:2.00,ibu:3,existencias:false},
    {id:3,marca:'Mahou',precio:1.70,ibu:1,existencias:true},
    {id:4,marca:'Estrella Galicia',precio:1.80,ibu:4,existencias:false},
    {id:5,marca:'1906',precio:2.10,ibu:5,existencias:true},
    {id:6,marca:'San Miguel',precio:1.60,ibu:2,existencias:true}
  ];

  constructor() { }

  public getCervezas(){
    return this.cervezas;
  }

  public buscarCerveza(id: number){
    return this.cervezas.filter((item: any) => {
      return item.id == id
    })[0];
  }
}

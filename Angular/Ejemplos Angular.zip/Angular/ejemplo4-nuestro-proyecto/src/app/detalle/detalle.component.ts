import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NegocioService } from '../services/negocio.service';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.css']
})
export class DetalleComponent implements OnInit {

  id: number = 0;
  cerveza:any;

  constructor(private ruta: ActivatedRoute, 
        private negocioService:NegocioService) { 
    this.id = this.ruta.snapshot.params['id'];
    this.cerveza = this.negocioService.buscarCerveza(this.id);

    console.log("Cerveza recibido: " + this.cerveza.marca);
  }

  ngOnInit(): void {
  }

}

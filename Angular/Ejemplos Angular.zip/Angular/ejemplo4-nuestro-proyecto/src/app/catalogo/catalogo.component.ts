import { Component, OnInit } from '@angular/core';
import { NegocioService } from '../services/negocio.service';

@Component({
  selector: 'app-catalogo',
  templateUrl: './catalogo.component.html',
  styleUrls: ['./catalogo.component.css']
})
export class CatalogoComponent implements OnInit {

  cervezas: any = [];
  
  // Inyectamos el servicio para poder obtener la lista de cervezas
  constructor(private negocioService: NegocioService) { 
    this.cervezas = this.negocioService.getCervezas();
  }

  ngOnInit(): void {
  }

}

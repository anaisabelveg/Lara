package com.example.servicios;

import org.aspectj.lang.ProceedingJoinPoint;

public class Aspectos {
	
	public void facturar() {
		System.out.println("Facturando");
	}
	
	public void pasarControl() {
		System.out.println("Pasando el control");
	}
	
	public void embarcar() {
		System.out.println("Embarcando");
	}
	
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	public void recogerEquipaje() {
		System.out.println("Recogiendo equipaje");
	}
	
	public void emergencia() {
		System.out.println("Huston tenemos un problema");
	}
	
	public void medirTiempo(ProceedingJoinPoint pjp) {
		// Antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomando tiempo de inicio");
		
		try {
			pjp.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// Despues
		long fin = System.currentTimeMillis();
		System.out.println("Duracion: " + (inicio-fin) + " mseg.");
	}

}










package com.example.cliente;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.negocio.Aeropuerto;

public class AppMain {

	public static void main(String[] args) {
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Aeropuerto aeropuerto = context.getBean("aeropuerto", Aeropuerto.class);
		
		aeropuerto.viajar();

	}

}

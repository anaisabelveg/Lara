package com.example.negocio;

public class Aeropuerto {
	
	public void viajar() {
		System.out.println("Me voy de vacaciones");
	}

}
